<template>
  <div class="time-query" ref="currentName">
    <el-radio-group v-if="quickBtn" class="quick-btn" v-model="tabPosition">
      <el-radio-button label="1">近一天</el-radio-button>
      <el-radio-button label="7">近一周</el-radio-button>
      <el-radio-button label="whole">全部</el-radio-button>
    </el-radio-group>
    <div class="time-query-input"  :class="{'select-border':isTimeList}">
      <div @click="handleShowList">
        <span><i class="fa fa-calendar calendar-icon"></i>&nbsp;&nbsp;&nbsp;</span>
        <input class="input" :value="startTimeValue" :placeholder="startPlaceholder"/>
        <span class="title-text">{{rangeSeparator}}</span>
        <input class="input" :value="endTimeValue" :placeholder="endPlaceholder"/>
      </div>
        <div class="time-list" :class="{hide:!isTimeList}">
          <div class="time-start-bg">{{startTime.month}}</div>
          <div class="time-end-bg">{{endTime.month}}</div>
          <div class="time-start">
            <div class="time-select">
              <span class="time-select-btn">
                 <i class="fa fa-angle-double-left direction-icon" @click="handleYear('reduce',startTime)" aria-hidden="true"></i>
                 <i class="fa fa-angle-left direction-icon" @click="handleMonth('reduce',startTime)" aria-hidden="true"></i>
              </span>
              <span class="time-select-value">{{startTimeString}}</span>
              <span class="time-select-btn time-select-btn-end">
                 <i class="fa fa-angle-right direction-icon" @click="handleMonth('plus',startTime)" aria-hidden="true"></i>
                 <i class="fa fa-angle-double-right direction-icon" @click="handleYear('plus',startTime)"  aria-hidden="true"></i>
              </span>
            </div>
            <table class="time-table" valign="middle" cellspacing="0">
              <thead>
                <tr class="table-head-row">
                  <td class="th-style">日</td>
                  <td class="th-style">一</td>
                  <td class="th-style">二</td>
                  <td class="th-style">三</td>
                  <td class="th-style">四</td>
                  <td class="th-style">五</td>
                  <td class="th-style">六</td>
                </tr>
              </thead>
            </table>
            <div class="time-data">
              <div v-for="(v,i) in d"
                   :key="i"
                   @click="v.currentMonth&&handleClickDay(v)"
                   @mouseenter="hoverTime=v"
                   :class="{
                   'select-bg-color-start':selectStartTime.day==v.day&&selectStartTime.month==v.month&&selectStartTime.year==v.year,
                   'select-bg-color-end':selectEndTime.day==v.day&&selectEndTime.month==v.month&&selectEndTime.year==v.year,
                   'between-time':isBetweenTime(v)&&v.currentMonth,
                   'select-bg-color':
                   (selectStartTime.day==v.day&&selectStartTime.month==v.month&&selectStartTime.year==v.year
                   ||selectEndTime.day==v.day&&selectEndTime.month==v.month&&selectEndTime.year==v.year)&&v.currentMonth}">
                <span :class="{'secondary-color':!v.currentMonth,'current-time':currentTime.day==v.day&&currentTime.month==v.month&&currentTime.year==v.year}" class="td-style">{{v.day}}</span>
              </div>
            </div>
          </div>
          <div class="time-end">
            <div class="time-select">
              <span class="time-select-btn">
                 <i class="fa fa-angle-double-left direction-icon" @click="handleYear('reduce',endTime)" aria-hidden="true"></i>
                 <i class="fa fa-angle-left direction-icon" @click="handleMonth('reduce',endTime)" aria-hidden="true"></i>
              </span>
              <span class="time-select-value">{{endTimeString}}</span>
              <span class="time-select-btn time-select-btn-end">
                 <i class="fa fa-angle-right direction-icon" @click="handleMonth('plus',endTime)" aria-hidden="true"></i>
                 <i class="fa fa-angle-double-right direction-icon" @click="handleYear('plus',endTime)"  aria-hidden="true"></i>
              </span>
            </div>
            <table class="time-table" valign="middle" cellspacing="0">
              <thead>
              <tr class="table-head-row">
                <td class="th-style">日</td>
                <td class="th-style">一</td>
                <td class="th-style">二</td>
                <td class="th-style">三</td>
                <td class="th-style">四</td>
                <td class="th-style">五</td>
                <td class="th-style">六</td>
              </tr>
              </thead>
            </table>
            <!--@mouseleave="v.isSelect=false"-->
            <div class="time-data">
              <div v-for="(v,i) in endD"
                   :key="i"
                   @mouseenter="hoverTime=v"
                   @click="v.currentMonth&&handleClickDay(v)"
                   :class="{
                   'select-bg-color-start':selectStartTime.day==v.day&&selectStartTime.month==v.month&&selectStartTime.year==v.year,
                   'select-bg-color-end':selectEndTime.day==v.day&&selectEndTime.month==v.month&&selectEndTime.year==v.year,
                   'between-time':isBetweenTime(v)&&v.currentMonth,
                   'select-bg-color':(selectStartTime.day==v.day&&selectStartTime.month==v.month&&selectStartTime.year==v.year||selectEndTime.day==v.day&&selectEndTime.month==v.month&&selectEndTime.year==v.year)&&v.currentMonth,
                   }"
              >
                <span :class="{'secondary-color':!v.currentMonth}"  class="td-style">{{v.day}}</span>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
    import mixinData from './mixinData'
    export default {
        mixins:[mixinData],
        name: "time-query",
        props:{
          quickBtn:{
            default:true
          },
          value:null,
          defaultTime:null,
          startPlaceholder:{
            default:"开始日期"
          },
          endPlaceholder:{
            default:"结束日期"
          },
          timeType:{
            type:String,
            default:'ordinary'
          },
          rangeSeparator:{
            type:String,
            default:'至'
          }
        },
        data(){
          return{
            tabPosition:"",
            isTimeList:false,
            d:[],
            endD:[],
            currentTime:{
              year:"",
              month:"",
              day:""
            },
            hoverTime:{
              year:"",
              month:"",
              day:""
            },
            selectStartTime:{
              year:"",
              month:"",
              day:""
            },
            selectEndTime:{
              year:"",
              month:"",
              day:""
            },
            startTime:{
              year:2018,
              month:1,
            },
            endTime:{
              year:2018,
              month:2,
            },
          }
        },
        computed:{
          startTimeString(){
            return this.startTime.year+'年'+ this.startTime.month + '月'
          },
          endTimeString(){
            return this.endTime.year+'年'+ this.endTime.month + '月'
          },
          startTimeValue(){
            if(this.selectStartTime.day){
              return this.handleStandardTime(this.selectStartTime)
            }else {
              return ''
            }
          },
          endTimeValue(){
            if(this.selectEndTime.day){
              return this.handleStandardTime(this.selectEndTime)
            }else {
              return ''
            }
          }
        },
        watch:{
          value(){
            var startTime = new Date(this.value[0])
            var endTime = new Date(this.value[1])

            this.selectStartTime = this.arrTransformationTime(startTime)
            this.selectEndTime = this.arrTransformationTime(endTime)
          },
          tabPosition(newDate){
            this.selectStartTime = this.initTime()
            this.selectEndTime = this.initTime()
            if(newDate!='whole'){
              var Millisecond = newDate*86400000
              var currentDate = new Date();
              this.selectEndTime.year = currentDate.getFullYear()
              this.selectEndTime.month = currentDate.getUTCMonth()+1
              this.selectEndTime.day = currentDate.getUTCDate()

              var startDate =  new Date(currentDate.getTime()-Millisecond)
              this.selectStartTime.year = startDate.getFullYear()
              this.selectStartTime.month = startDate.getUTCMonth()+1
              this.selectStartTime.day = startDate.getUTCDate()
            }
          },
          startTime:{
            handler(newData){
              this.handleCalculation(newData,'d')
            },
            deep:true
          },
          endTime:{
            handler(newData){
              this.handleCalculation(newData,'endD')
            },
            deep:true
          },
          isTimeList(val){
            if(val){
              document.addEventListener('click',this.fn,true)
            }else {
              document.removeEventListener('click',this.fn,true)
            }
          }
        },
        methods:{
          //字符串时间转对象
          arrTransformationTime(arr){
            return {
                year:arr.getFullYear(),
                month: arr.getMonth()+1,
                day: arr.getDate()
              }
          },
          //对象时间转字符串
          handleStandardTime(val){
            var month = val.month>=10?val.month:'0'+val.month
            var day = val.day>=10?val.day:'0'+val.day
            return val.year + '-' + month + '-' + day
          },
          //判断是否为选中时间之间的时间
          isBetweenTime(v){
            if(this.selectStartTime.day&&this.selectEndTime.day){
              var startTime = new Date(this.handleStandardTime(this.selectStartTime))
              var endtTime = new Date(this.handleStandardTime(this.selectEndTime))
              var currentTime = new Date(this.handleStandardTime(v))
              return currentTime>startTime&&currentTime<endtTime
            }else if(this.selectStartTime.day&&this.hoverTime.day){
              var startTime = new Date(this.handleStandardTime(this.selectStartTime))
              var endtTime = new Date(this.handleStandardTime(this.hoverTime))
              var currentTime = new Date(this.handleStandardTime(v))
              return currentTime>startTime&&currentTime<endtTime
            }
          },
          //获取当前时间
          handleCurrentDate(){
            var currentDate = new Date();

            this.currentTime.year = currentDate.getFullYear()
            this.currentTime.month = currentDate.getMonth()+1
            this.currentTime.day = currentDate.getDate()

            this.endTime.year = currentDate.getFullYear()
            this.endTime.month = currentDate.getMonth()+1

            var endTimeStamp = currentDate.getTime()-2678400000
            var endTime = new Date(endTimeStamp)
            
            this.startTime.year = endTime.getFullYear()
            this.startTime.month = endTime.getMonth()+1
          },
          fn(e){
            var slef = this;
            var parentNode =  this.$refs.currentName;
            var isChildNode = parentNode.contains(e.target);
            !isChildNode && (slef.isTimeList = false)
          },
          handleShowList(){
            this.isTimeList = true
          },
          //输出时间
          handleInput(start,end){
            var value = [];
            if(this.timeType=='ordinary'){
              value[0] = this.handleStandardTime(start)
              value[1] = this.handleStandardTime(end)
            }else if(this.timeType=='stamp'){
              value[0] =  (new Date(this.handleStandardTime(start))).getTime()
              value[1] =  (new Date(this.handleStandardTime(end))).getTime()
            }else if(this.timeType=='standard'){
              value[0] = new Date(this.handleStandardTime(start))
              value[1] = new Date(this.handleStandardTime(end))
            }
            this.$emit('input',value)
          },
          //点击选择日期
          handleClickDay(val){
            if(this.selectStartTime.day&&this.selectEndTime.day){
              this.selectEndTime = this.initTime()
              this.selectStartTime = this.initTime()
            }
            if(!this.selectStartTime.day){
              this.selectStartTime = val
            }else {
              this.selectEndTime = val
            }
            if(this.selectStartTime.day&&this.selectEndTime.day){
              this.isTimeList = false
              this.handleInput(this.selectStartTime,this.selectEndTime)
            }
          },
          initTime(){
            return {year:"", month:"", day:""}
          },
          //变换年份
          handleYear(is,time){
            if(is === 'plus'){
              time.year++;
            }else {
              time.year--;
            }
          },
          //变换月份
          handleMonth(is,time){
            if(is === 'plus'&&time.month==12){
              time.month = 1;
              time.year++;
            }else if(is === 'plus'&&time.month!=12){
              time.month++;
            }else if(time.month==1){
              time.year--;
              time.month = 12
            }else {
              time.month--;
            }
          },
          handleCalculatedDays(year,month){
            let monthD
            if(month==2){
              var isRun = (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)
              monthD = isRun?28:29
            }else {
              monthD = this.daySumData['m'+month]
            }
            return monthD
          },
          handleCalculation(endTime,obj){
            var startTimeValue = endTime.year+'-'+ endTime.month + '-'+'01';
            var d = new Date(startTimeValue).getDay()
            var weekDay = d;

            var monthD = this.handleCalculatedDays(endTime.year,endTime.month);
            var tMonthD = "";
            var tYear = "";
            var tMonth = "";
            if(endTime.month==1){
              tYear = endTime.year-1;
              tMonth = 12
              tMonthD = this.handleCalculatedDays(tYear,tMonth);
            }else {
              tYear = endTime.year
              tMonth = endTime.month-1
              tMonthD = this.handleCalculatedDays(endTime.year,endTime.month-1);
            }
            var hYear = "";
            var hMonth = "";
            if(endTime.month==12){
              hYear = endTime.year+1;
              hMonth = 1
            }else {
              hYear = endTime.year
              hMonth = endTime.month+1
            }

            const sum = 42;
            var d = 1;
            var hd = 1;
            var arr = [];
            while (arr.length<sum){
              if(weekDay>0){
                arr.push({
                  day:tMonthD-weekDay+1,
                  year:tYear,
                  month:tMonth,
                  currentMonth:false
                });
                weekDay--;
              }else if(d<=monthD){
                arr.push({
                  day:d,
                  currentMonth:true,
                  year:endTime.year,
                  month:endTime.month
                })
                d++
              }else {
                arr.push({
                  day:hd,
                  currentMonth:false,
                  year:hYear,
                  month:hMonth
                })
                hd++
              }
            }
            this[obj] = arr
          }
        },
        beforeDestroy(){
          document.removeEventListener('click',this.fn,true)
        },
        created(){
          //传入时间
          var startTime = new Date(this.value[0])
          var endTime = new Date(this.value[1])
          this.selectStartTime = this.arrTransformationTime(startTime)
          this.selectEndTime = this.arrTransformationTime(endTime)

          this.handleCurrentDate()
          this.handleCalculation(this.startTime,'d')
          this.handleCalculation(this.endTime,'endD')
        }
    }
</script>

<style scoped>
  @import "css/font-awesome-4.7.0/css/font-awesome.min.css";

  div,span,input,table,tr,td,th,i{
    box-sizing: border-box;
    font-family: 'Source Han Sans CN';
  }
  .main-color{
    color: #606266;
  }
  .secondary-color{
    color: #C0C4CC;
  }
  .select-bg-color-start{
    background:  #F2F6FC;
    border-top-left-radius: 15px;
    border-bottom-left-radius: 15px;
  }
  .select-bg-color-end{
    background:  #F2F6FC;
    border-top-right-radius: 15px;
    border-bottom-right-radius: 15px;
  }
  .select-bg-color>span{
    /*background-color: #409EFF;*/
    display: block;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    color: #FFFFFF;
    background-color: #409EFF
  }
  .select-bg-color>span{
    color: #ffffff;
  }
  .time-data{
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    padding: 0 15px;
  }
  .td-style{
    font-size: 12px;
  }
  .time-data>div{
    width: 38px;
    height: 30px;
    margin-bottom: 5px;
    line-height: 30px;
    text-align: center;
    color: #606266;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    cursor: pointer;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
  }
  .time-data>div>span{
    width: 28px;
    height: 28px;
    line-height: 28px;
    border-radius: 50%;
  }
  tr{
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }

  .time-data>div:hover {
    background:  #F2F6FC;
    border-top-right-radius: 15px;
    border-bottom-right-radius: 15px;
  }

  .time-data>div>span:hover {
    display: block;
    color: #FFFFFF;
    background-color: #409EFF;
  }
  .time-query{
    z-index: 999;
    height: 100%;
    display: flex;
    -webkit-display:flex;
    align-items: center;
  }
  .time-table{
    padding: 0 15px;
    width: 100%;
  }
  .th-style{
    height: 35px;
    line-height: 35px;
    text-align: center;
    color: #606266;
    border-bottom: 1px solid #E4E7ED;
    font-size: 12px;
  }
  .calendar-icon{
    color: #C0C4CC;
    font-size: 13px;
  }
  .time-query-input{
    display: inline-block;
    width: 350px;
    height: 32px;
    line-height: 32px;
    border: 1px solid #dcdfe6;
    border-radius: 4px;
    text-align: left;
    color: #909399;
    padding-left: 10px;
    position: relative;
  }
  .direction-icon{
    padding: 0 4px;
    font-size: 18px;
    cursor: pointer;
  }
  .direction-icon:hover{
    color: #409EFF;
  }
  .quick-btn{
    margin-right: 5px;
  }
  .input{
    width: 110px;
    background: none;
    height: 32px;
    border: none;
    outline: none;
    font-size: 13px;
    padding: 0 15px;
    text-align: center;
    color: #606266;
  }
  .title-text{
    display: inline-block;
    width: 50px;
    text-align: center;
  }
  .input::-webkit-input-placeholder{
    color: #C0C4CC;
  }
  .time-list{
    position: absolute;
    top: 35px;
    left: 0;
    width: 600px;
    height: 302px;
    background: #ffffff;
    display: flex;
    flex-wrap: nowrap;
    box-shadow: 1px 1px 10px #E4E7ED;
    transition: .15s;
    overflow: hidden;
    z-index: 9999;
  }
  .time-list>div{
    border: #E4E7ED 1px solid;
    width: 300px;
    height: auto;
    padding-bottom: 20px;
    position: absolute;
    background: #ffffff;
    overflow: hidden;
  }
  .time-start{
    border-radius: 5px;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 999;
  }
  .time-end{
    border-radius: 5px;
    position: absolute;
    top: 0;
    left: 300px;
    z-index: 999;
  }
  .time-start-bg{
    position: absolute;
    color: #C0C4CC;
    width: 300px;
    top: 0;
    left: 0;
    height: 300px;
    line-height: 302px;
    text-align: center;
    font-size: 170px;
    font-weight: 600;
    opacity: 0.12;
  }
  .time-end-bg{
    position: absolute;
    width: 300px;
    color: #C0C4CC;
    top: 0;
    left: 300px;
    height: 300px;
    line-height: 302px;
    text-align: center;
    font-size: 170px;
    font-weight: 600;
    opacity: 0.1;
  }
  .time-select{
    display: flex;
    margin: 0;
    height: 40px;
    line-height: 40px;
    padding: 0 15px;
    /*background: #409EFF;*/
    background: #65affc;
    color: #fff;
  }
  .time-select-value{
    display: inline-block;
    width: 160px;
    text-align: center;
    color: #ffffff;
    /*font-weight: 600;*/
    font-size: 15px;
  }
  .time-select-btn{
    display: inline-block;
    width: 90px;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }
  .time-select-btn-end{
    text-align: right;
  }
  .select-border{
    border: 1px solid #409EFF;
  }
  .hide{
    height: 0;
  }
  .show{
    height:302px;
  }
  .current-time{
    font-weight: 600 !important;
    color: #409EFF;
  }
  .between-time{
    background: #F2F6FC;
  }
</style>
