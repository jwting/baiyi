import navigationBar from './src/navigation-bar'

export default function (Vue) {
  Vue.component(navigationBar.name,navigationBar)
}
