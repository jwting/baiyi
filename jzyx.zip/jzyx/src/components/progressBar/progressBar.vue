<template>
  <!--进度条-->
  <div>
    <div v-if="proDisplay" class="app">
      <el-progress :text-inside="true" :stroke-width="12" :percentage="toSelectNumber"></el-progress>
      <div class="tips">
        <span
          :style="toSelectNumber<100?'':'color:#67C23A;'"
          :class="toSelectNumber<100?'el-icon-loading':'el-icon-success'"
        ></span>
        <span class="color">{{toSelectNumber==100?"&nbsp;&nbsp;加载成功":"&nbsp;&nbsp;加载中 请稍后"}}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "progressBar",
  props: ["isDisplay"],
  data() {
    return {
      toSelectNumber: 0,
      selectNumberInterval: null,
      proDisplay: false
    };
  },
  watch: {
    isDisplay(newVal) {
      if (newVal) {
        this.proDisplay = newVal;
        this.setSelectNumberInterval();
      } else {
        this.destructionInterval();
      }
    }
  },
  methods: {
    //进度条定时器
    setSelectNumberInterval: function() {
      var that = this;
      //初始化进度条定时器
      that.toSelectNumber = 0;
      var t = 0;
      //设置定时器
      that.selectNumberInterval = setInterval(function() {
        var i = 0;
        if (that.toSelectNumber <= 60) {
          i = Math.random() / 2;
        } else if (that.toSelectNumber > 60 && that.toSelectNumber <= 90) {
          i = Math.random();
          i = i / 10;
        } else if (that.toSelectNumber > 90 && that.toSelectNumber < 95) {
          t++;
          if (t > 20) {
            i = Math.random();
            i = i / 15;
          }
        } else if (that.toSelectNumber > 95 && that.toSelectNumber < 98.5) {
          i = Math.random();
          i = i / 30;
        }
        var num = that.toSelectNumber;
        num += i;
        num = parseFloat(num).toFixed(2);
        num = parseFloat(num);
        if (num >= 100) {
          num = 100;
        }
        that.toSelectNumber = num;
      }, 500);
    },
    //销毁定时器
    destructionInterval: function() {
      var that = this;
      clearInterval(that.selectNumberInterval);
      var m = 0;
      that.selectNumberInterval = setInterval(function() {
        if (m == 0) {
          var i = (100 - that.toSelectNumber) / 2;
          var ber = that.toSelectNumber + i;
          that.toSelectNumber = parseFloat(parseFloat(ber).toFixed(2));
          m++;
        } else if (m == 1) {
          that.toSelectNumber = 100;
          m++;
        } else {
          that.proDisplay = false;
          that.$emit("closeChange", this.proDisplay);
          that.toSelectNumber = 0;
          clearInterval(that.selectNumberInterval);
        }
      }, 300);
    }
  },
  created() {
    this.setSelectNumberInterval();
  }
};
</script>

<style scoped>
.app {
  height: 80px;
  width: 100%;
  text-align: center;
  padding-top: 20px;
}
.tips {
  text-align: center;
  margin-top: 5px;
}
.color {
  color: #8a8a8a;
}
</style>