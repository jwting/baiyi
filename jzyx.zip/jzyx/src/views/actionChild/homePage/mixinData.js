
export default {
    data() {
        return {
            homeData: {},
            sneakData: {},
            pageList:[
                {
                    icon:"iconfont icon-zhinengsuanfa",
                    path:"Intelligent",
                    title:"智能筛选",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-xiansuo",
                    path:"screening",
                    title:"线索筛选",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-ziyuan",
                    path:"myClue",
                    title:"我的线索",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-gongsi-",
                    path:"companyClue",
                    title:"公司线索",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-drxx27",
                    path:"departmentalClues",
                    title:"部门线索",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-huishouzhan",
                    path:"recycleBin",
                    title:"回收站",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-zuorigaikuang",
                    path:"yesterdayStatistics",
                    title:"昨日概况",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-zhediexiaoguo",
                    path:"followUpStatistics",
                    title:"跟进效果",
                    alt:"通过条件线索筛选出线索"
                },
                {
                    icon:"iconfont icon-tongji",
                    path:"currentStatistics",
                    title:"当前统计",
                    alt:"通过条件线索筛选出线索"
                }
           ],
           moreList:[
               {
                    icon:"iconfont icon-xiaochengxu",
                    path:"smallProgram",
                    title:"小程序",
                    alt:"使用小程序"
                } 
           ]
        }
    },
}