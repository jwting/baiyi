<template>
    <div class="action_child">
        <action_tit title="昨日概况"></action_tit>
        <div>
            <div class="yes-tit"><i class="fa fa-building" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;公司</div>
            <div class="compony-box">
                <div class="new-potential-customers">
                    <div class="new-potential-customers-tit">新增潜客</div>
                    <div class="new-potential-customers-box">
                        <div class="circular">
                            <p class="circular-text">成单</p>
                            <p class="circular-shape">{{addA}}</p>
                        </div>
                        <ul class="circular-text">
                            <li>
                            <p>有兴趣</p>
                            <p class="circular-text-number">{{addB}}</p> 
                            </li>
                            <li>
                            <p>暂无需求</p>
                            <p class="circular-text-number">{{addC}}</p> 
                            </li>
                            <li>
                            <p>没有兴趣</p>
                            <p class="circular-text-number">{{addD}}</p> 
                            </li>
                            <li>
                            <p>打不通电话</p>
                            <p class="circular-text-number">{{addE}}</p> 
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="sneak-conversion">
                    <div>
                        <div class="new-potential-customers-tit">潜客转化</div>   
                        <canvas id="sneak-conversion"></canvas>
                    </div>
                </div>
                <div class="total">
                    <div class="new-potential-customers-tit">总数</div>   
                    <ul class="circular-text">
                         <li>
                            <p>成单</p>
                            <p class="circular-text-number">{{companyData.allCount.countA}}</p> 
                        </li>
                        <li>
                            <p>有兴趣</p>
                            <p class="circular-text-number">{{companyData.allCount.countB}}</p> 
                        </li>
                        <li>
                            <p>暂无需求</p>
                            <p class="circular-text-number">{{companyData.allCount.countC}}</p> 
                        </li>
                        <li>
                            <p>没有兴趣</p>
                            <p class="circular-text-number">{{companyData.allCount.countD}}</p> 
                        </li>
                        <li>
                            <p>打不通电话</p>
                            <p class="circular-text-number">{{companyData.allCount.countE}}</p> 
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div>
             <div class="yes-tit-footer">
                <div>
                    <div>
                        <i class="fa fa-sitemap" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;部门&nbsp;&nbsp;&nbsp;
                        <el-select class="dep-select" v-model="depValue" placeholder="请选择">
                            <el-option
                            v-for="item in depList"
                            :key="item.id"
                            :label="item.deptName"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="yes-table">
                        <ul class="table-text">
                           <li>&nbsp;</li>
                           <li>新增潜客</li>
                           <li>前日潜客</li> 
                        </ul>
                        <ul class="table-list">
                            <li>
                                <ul class="table-list-row-h">
                                    <li>A</li>
                                    <li>B</li>
                                    <li>C</li>
                                    <li>D</li>
                                    <li>E</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="table-list-rows">
                                    <li class="table-bga">{{depTableData.yesCustCount.countA}}</li>
                                    <li>{{depTableData.yesCustCount.countB}}</li>
                                    <li>{{depTableData.yesCustCount.countC}}</li>
                                    <li>{{depTableData.yesCustCount.countD}}</li>
                                    <li>{{depTableData.yesCustCount.countE}}</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="table-list-rows">
                                    <li>{{depTableData.befYesCustCount.countA}}</li>
                                    <li>{{depTableData.befYesCustCount.countB}}</li>
                                    <li>{{depTableData.befYesCustCount.countC}}</li>
                                    <li>{{depTableData.befYesCustCount.countD}}</li>
                                    <li>{{depTableData.befYesCustCount.countE}}</li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                   <div>
                        <i class="fa fa-user-circle-o" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;员工&nbsp;&nbsp;&nbsp;
                        <el-select class="dep-select" v-model="staffValue" placeholder="请选择">
                            <el-option
                            v-for="item in employeeList"
                            :key="item.id"
                            :label="item.nickName"
                            :value="item.id">
                            </el-option>
                        </el-select>
                   </div>
                   <div class="yes-table">
                        <ul class="table-text">
                           <li>&nbsp;</li>
                           <li>新增潜客</li>
                           <li>前日潜客</li> 
                        </ul>
                        <ul class="table-list">
                            <li>
                                <ul class="table-list-row-h">
                                    <li>A</li>
                                    <li>B</li>
                                    <li>C</li>
                                    <li>D</li>
                                    <li>E</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="table-list-rows">
                                    <li class="table-bga">{{staffTableData.yesCustCount.countA}}</li>
                                    <li>{{staffTableData.yesCustCount.countB}}</li>
                                    <li>{{staffTableData.yesCustCount.countC}}</li>
                                    <li>{{staffTableData.yesCustCount.countD}}</li>
                                    <li>{{staffTableData.yesCustCount.countE}}</li>
                                </ul>
                            </li>
                            <li>
                                <ul class="table-list-rows">
                                    <li>{{staffTableData.befYesCustCount.countA}}</li>
                                    <li>{{staffTableData.befYesCustCount.countB}}</li>
                                    <li>{{staffTableData.befYesCustCount.countC}}</li>
                                    <li>{{staffTableData.befYesCustCount.countD}}</li>
                                    <li>{{staffTableData.befYesCustCount.countE}}</li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
             </div>
        </div>
    </div>
</template>

<script>
import Action_tit from "../publicComponent/action_tit/action_tit.vue";
import mixinData from "./mixin-yesterday-data.js";
import mixinMounted from "./mixin-yesterday-mounted.js";
export default {
    mixins:[mixinData,mixinMounted],
    components: {Action_tit},
    name:'yesterdayStatistics',
    computed:{
        addA(){
            let value = this.companyData.yesCustCount.countA 
            if(value){
                return value
            }else{
                return 0
            }
        },
        addB(){
            let value = this.companyData.yesCustCount.countB
            if(value){
                return value
            }else{
                return 0
            }
        },
        addC(){
           let value = this.companyData.yesCustCount.countC
            if(value){
                return value
            }else{
                return 0
            }
        },
        addD(){
            let value = this.companyData.yesCustCount.countD
            if(value){
                return value
            }else{
                return 0
            }
        },
        addE(){
            let value = this.companyData.yesCustCount.countE
            if(value){
                return value
            }else{
                return 0
            }
        },
    },
    watch: {
        depValue(){
            this.getEmployeeList()
            this.queryDeptCustCountByDate(this.depValue)
        },
        staffValue(){
            this.queryUserCustCountByDate(this.staffValue)
        }
    },
    methods:{
        
    },
    created(){
        this.queryComCustCountByDate()

        this.depValue = parseInt(window.localStorage['dId'])

        this.getDepartmentList()

        this.queryUserCustCountByDate(window.localStorage['id'])
    }
}
</script>

<style scoped>
    .table-list-row-h>li{
        float: left;
        width: 20%;
        text-align: center;
        border-right: #DCDFE6 solid 1px;
        border-bottom: #DCDFE6 solid 1px;
    }
    .table-bga{
        background: #F2F6FC;
    }
    .table-list-rows>li{
        float: left;
        width: 20%;
        text-align: center;
        border-right: #DCDFE6 solid 1px;
        border-bottom: #DCDFE6 solid 1px;
        height: 40px;
    }
    .table-text{
        width: 140px;
    }
    .table-list{
        flex-grow: 1;
        padding-right: 50px;
    }
    .yes-table{
        display: flex;
        margin-top: 25px;
    }
    .yes-table>ul>li{
        height: 38xp;
        line-height: 38px;
        text-align: left;
    }
    .yes-table>ul>li>ul>li:first-child{
        border-left: #DCDFE6 solid 1px;
    }
    .yes-table>ul>li:first-child>ul>li:first-child{
        border-left: none;
    }
    .yes-table>ul>li:first-child>ul>li:last-child{
       border-right: none;
    }
    .dep-select{
        width: 120px;
    }
    .yes-tit-footer{
        color: #606266;
        line-height: 42px;
        padding-left: 15px;
        display: flex;
    }
    .yes-tit-footer>div{
        width: 100%;
        padding-bottom: 20px;
    }
    .yes-tit-footer>div:nth-of-type(1){
        border-right: #E4E7ED solid 1px;
    }
    .yes-tit-footer>div:nth-of-type(2){
        padding-left: 20px;
    }
    #sneak-conversion{
        display: block;
        margin: 0 auto;
    }
    .yes-tit{
        /* background: #EBEEF5; */
        color: #606266;
        height: 42px;
        line-height: 42px;
        padding-left: 15px;
        border-bottom:  #E4E7ED solid 1px;
    }
    .compony-box{
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between; 
        border-bottom:  #E4E7ED solid 1px;
    }
    .compony-box>div{
        padding-top: 20px;
    }
    .sneak-conversion{
        border-right: 1px solid #E4E7ED; 
        width: 38%;
        text-align: center;
    }
    .sneak-conversion>div{
        width: 100%;
        height: 100%;
    }
    .total{
        flex-grow: 1;
        padding: 0 20px;
    }
    .circular-text{
        flex-grow: 1;
        padding: 0 20px;
    }
    .new-potential-customers{
        padding-bottom: 10px;
        /* width: 33%; */
        flex-grow: 1;
        border-right: 1px solid #E4E7ED; 
    }
    .new-potential-customers-box{
        display: flex;
        flex-wrap: nowrap;
        padding-left: 20px; 
    }
    .new-potential-customers-tit{
        width: 100%;
        text-align: center;
        height: 50px;
        line-height: 50px;
    }
    .circular{
        width: 140px;
    }
    .circular-text{
        text-align: center;
        line-height: 50px;
        height: 45px;
    }
    .circular-text-number{
        color: #409EFF;
        font-weight: 600;
    }
    .circular-shape{
        margin: 0 auto;
        width: 140px;
        height: 140px;
        line-height: 130px;
        border-radius: 50%;
        border: 5px solid #E4E7ED;
        text-align: center;
        font-size: 55px;
        font-weight: 600;
        color: #409EFF;
    }
    .circular-text>li{
        line-height: 55px;
        height: 55px;
    }
    .circular-text>li>p{
        width: 50%;
        float: left;
    }
    .circular-text>li>p:nth-of-type(1){
        text-align: left;
        padding-left: 30px;
    }
    .circular-text>li>p:nth-of-type(2){
        text-align: right;
        padding-right: 30px;
    }
</style>