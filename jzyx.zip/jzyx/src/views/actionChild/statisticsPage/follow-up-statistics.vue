<template>
    <div class="action_child statistics">
        <action_tit title="跟进效果"></action_tit>
        <div class="time-row">
            <span>统计日期：&nbsp;&nbsp;&nbsp;</span>
            <time-query time-type="ordinary" v-model="time" :quick-btn="false" range-separator="至"></time-query>
        </div>
        <div>
            <div class="fllow-tit"><i class="fa fa-building" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;公司</div>
            <div class="statistics-box">
                <div class="statistics-funnel">
                    <div id="funnel" class="funnel"></div>
                    <ul class="funnel-text">
                        <li v-for="(v,i) in funnelText" :key="i">
                            <p><span>{{v.type}}&nbsp;&nbsp;&nbsp;</span><span>{{v.orderForm}}</span></p>
                            <p><span>占比&nbsp;&nbsp;&nbsp;</span><span>{{v.proportion}}</span></p>
                        </li>
                    </ul>
                    <div class="funnel-name">整体跟进效果图</div>
                </div>
                <div class="statistics-Columnar">
                    <div class="select-list">
                        <el-select v-model="comValue" placeholder="请选择">
                            <el-option
                            v-for="item in custTypeData"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="company-histogram"></div>
                    <div class="funnel-name">部门跟进效果比较图</div>
                </div>
            </div>
        </div>
        <div>
            <div class="fllow-tit"><i class="fa fa-sitemap" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;部门</div>
            <div class="statistics-box">
                <div class="dep-statistics-list">
                    <div class="dep-select">
                        <el-select v-model="depValue" placeholder="请选择">
                            <el-option
                            v-for="item in depList"
                            :key="item.id"
                            :label="item.deptName"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="circular">
                        <p class="circular-text">成单</p>
                        <p class="circular-shape">{{depData.custCount.countA}}</p>
                    </div>
                    <ul class="circular-text" v-if="depData.custCount">
                        <li>
                           <p>有兴趣</p>
                           <p class="circular-text-number">{{depData.custCount.countB}}</p>
                        </li>
                        <li>
                           <p>暂无需求</p>
                           <p class="circular-text-number">{{depData.custCount.countC}}</p> 
                        </li>
                        <li>
                           <p>没有兴趣</p>
                           <p class="circular-text-number">{{depData.custCount.countC}}</p> 
                        </li>
                        <li>
                           <p>打不通电话</p>
                           <p class="circular-text-number">{{depData.custCount.countE}}</p> 
                        </li>
                    </ul>
                    <div class="funnel-name dep-name">部门跟进效果比较图</div>
                </div>
                <div class="dep-statistics-Columnar">
                    <div class="dep-select">
                        <el-select v-model="depType" placeholder="请选择">
                            <el-option
                            v-for="item in custTypeData"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="dep-histogram"></div>
                    <div class="funnel-name">部门跟进效果比较图</div>
                </div>
            </div>
        </div>
        <div>
            <div class="fllow-tit"><i class="fa fa-user-circle-o" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;员工</div>
            <div class="statistics-box">
                <div class="dep-statistics-list">
                    <div class="dep-select">
                        <el-select v-model="staffValue" placeholder="请选择">
                            <el-option
                            v-for="item in employeeList"
                            :key="item.id"
                            :label="item.nickName"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </div>
                    <div class="circular">
                        <p class="circular-text">成单</p>
                        <p class="circular-shape">{{staffData.custCount.countA}}</p>
                    </div>
                    <ul class="circular-text">
                        <li>
                           <p>有兴趣</p>
                           <p class="circular-text-number">{{staffData.custCount.countB}}</p> 
                        </li>
                        <li>
                           <p>暂无需求</p>
                           <p class="circular-text-number">{{staffData.custCount.countC}}</p> 
                        </li>
                        <li>
                           <p>没有兴趣</p>
                           <p class="circular-text-number">{{staffData.custCount.countC}}</p> 
                        </li>
                        <li>
                           <p>打不通电话</p>
                           <p class="circular-text-number">{{staffData.custCount.countE}}</p> 
                        </li>
                    </ul>
                </div>
                <div class="dep-statistics-Columnar">
                    <div class="staff-tit">用户成单率</div>
                    <span class="staff-number">{{staffValueA}}</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Action_tit from "../publicComponent/action_tit/action_tit.vue";
import mixinData from "./mixin-follow-up-data.js";
import mixinMounted from "./mixin-follow-up-mounted.js";
import echarts from "echarts";
export default {
    mixins:[mixinData,mixinMounted],
    components: {Action_tit},
    name:'followUpStatistics',
    data(){
        return{
            time:[]
        }
    },
    computed:{
        staffValueA(){
            if(this.staffData.custCount.countA){
                var sum = this.staffData.custCount.countA+this.staffData.custCount.countB+this.staffData.custCount.countC
                +this.staffData.custCount.countD+this.staffData.custCount.countE
                return parseInt(this.staffData.custCount.countA/sum*100) + '%'
            }else{
                return 0
            }
        
        }
    },
    watch:{
        //个人变化 重新获取数据
        staffValue(){
            this.queryUserCustEffect()
        },
        //部门变化 重新获取数据
        depValue(){
            this.queryDeptCustEffect()
            this.getEmployeeList()
        },
        //部门潜客类型变化 重新获取数据
        depType(){
            this.queryDeptCustEffect()
        },
        //公司潜客类型变化 重新获取数据
        comValue(){
            this.queryCustEffect()
        },
        time(){
            //获取公司数据
            this.queryCustEffect()
            //获取部门数据
            this.queryDeptCustEffect()
            //获取个人
            this.queryUserCustEffect()
        }
    },
    created(){
        //获取部门列表
        this.getDepartmentList()
        //初始默认时间
        this.getCurrenTime()
         
        this.depValue = parseInt(window.localStorage['dId'])
        //获取个人
        this.queryUserCustEffect()
    }
}
</script>

<style scoped>
    .staff-tit{
        margin-top: 52px;
    }
    .statistics{
        padding-top: 10px;
    }
    .statistics-box{
        display: flex;
        justify-content: space-between;
        flex-wrap: nowrap;
        margin-bottom: 20px;
        margin-top: -20px;
    }
    .statistics-funnel{
        flex-grow: 1;
        border-right: 1px solid #EBEEF5; 
        display: flex;
        padding: 0 15px;
        flex-wrap: wrap
    }
    .statistics-Columnar{
        width: 500px;
    }
    .time-row{
        text-align: left;
        padding-left: 10px;
        margin-top: 10px;
        margin-bottom: 10px;
        height: 40px;
        line-height: 40px;
    }
    .time-row>span{
        color: #909399;
    }
    .follow-btn{
        margin-left: 15px;
    }
    .time-row>div{
        display: inline-block;
    }
    .fllow-tit{
        background: #EBEEF5;
        color: #606266;
        height: 42px;
        line-height: 42px;
        padding-left: 15px;
        margin-top: 10px;
    }
    .funnel-name{
        width: 100%;
        margin-top: -40px;
        text-align: center;
        font-size: 12px;
        color: #909399;
    }
    .funnel{
        width: 340px;
        height:500px;
    }
    .funnel-text{
        flex-grow: 1;
        padding-top: 59px;
        margin-right: 30px;
    }
    .funnel-text>li{
        height: 75px;
        line-height: 75px;
        border-top: 1px solid #d9e8f8;
        display: flex;
        justify-content: space-around;
        color: #606266;
        padding: 0 15px;
    }
    .funnel-text>li:last-child{
        border-bottom: 1px solid #d9e8f8;
    }
    .funnel-text>li>p>span:last-child{
        color: #409EFF;
    }
    .funnel-text>li>p:first-child{
        /* margin-right: 50px; */
    }
    .select-list{
        margin-top: 55px;
        padding-left: 25px;
    }
    .company-histogram{
        width: 400px;
        height: 400px;
        margin-left: 25px;
    }
    .dep-statistics-list{
        flex-grow: 1;
        display: flex;
        flex-wrap: wrap;
        padding-left: 30px;
        border-right: 1px solid #EBEEF5;
        align-self: flex-start; 
    }
    .staff-number{
        display: block;
        font-size: 100px;
        line-height: 280px;
        text-align: center;
        color: #409EFF;
    }
    .dep-statistics-Columnar{
        padding-left: 15px;
        width: 650px;
    }
    .dep-statistics-Columnar>div{
        padding-left: 15px;
    }
    .dep-select{
        width: 100%;
        height: 40px;
        margin-top: 55px;
        margin-bottom: 20px;
    }
    .circular{
        width: 180px;
    }
    .circular-text{
        text-align: center;
        margin-bottom: 15px;
        line-height: 20px;
        height: 20px;
    }
    .circular-text-number{
        color: #409EFF;
        font-weight: 600;
    }
    .circular-shape{
        margin: 0 auto;
        width: 180px;
        height: 180px;
        line-height: 170px;
        border-radius: 50%;
        border: 5px solid #E4E7ED;
        text-align: center;
        font-size: 70px;
        font-weight: 600;
        color: #409EFF;
    }
    .circular-text{
        flex-grow: 1;
        padding: 0 20px;
    }
    .circular-text>li{
        line-height: 55px;
        height: 55px;
        border-bottom: 1px solid #d9e8f8;
        /* line-height: 20px;
        height: 20px;
        margin-bottom: 50px; */
    }
    .circular-text>li>p{
        width: 40%;
        float: left;
    }
    .dep-histogram{
        width: 590px;
        height: 500px;
        margin-left: 15px;
    }
    .dep-name{
        margin-top: 50px;
    }
</style>