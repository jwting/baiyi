export default {
    data(){
        return {
            employeeList:[],
            staffValue:'',
            depList:[],
            depType:"B",
            funnelText:[],
            depValue:'',
            comValue:'B',
            custTypeData:[
                {
                  value: 'A',
                  label: 'A:成单'
                }, {
                  value: 'B',
                  label: 'B:有兴趣'
                }, {
                  value: 'C',
                  label: 'C:暂无需求'
                }, {
                  value: 'D',
                  label: 'D:不感兴趣/挂电话'
                }, {
                  value: 'E',
                  label: 'E:接不通'
                }
            ],
            //公司数据
            companyData: {},
            companyHistogramOption:{
                color: ['#3398DB'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    containLabel: true
                },
                xAxis:{
                    type : 'category',
                    data : [],
                    axisTick: {
                        alignWithLabel: true
                    }
                },
                yAxis:{
                        type : 'value'
                },
                series:{
                    name:'数量',
                    type:'bar',
                    barWidth: '60%',
                    data:[]
                }
            },
            depHistogramOption:{
                color: ['#3398DB'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    containLabel: true
                },
                xAxis:{
                    type : 'category',
                    data : [],
                    axisTick: {
                        alignWithLabel: true
                    }
                },
                yAxis:{
                        type : 'value'
                },
                series:{
                    name:'数量',
                    type:'bar',
                    barWidth: '60%',
                    data:[
                        {
                            value:"20",
                            name:"A"
                        },
                        {
                            value:"40",
                            name:"B"
                        },
                        {
                            value:"60",
                            name:"C"
                        },
                        {
                            value:"80",
                            name:"D"
                        },
                        {
                            value:"100",
                            name:"E"
                        }
                    ]
                }
            },
            funnelPoption:{
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c}%"
                },
                calculable: true,
                color: ["#1083f9","#62affe","#a1cbf7","#9acbfd","#c1ddfa"],
                series: {
                    sort: 'ascending',
                    name: '漏斗图',
                    type: 'funnel',
                    width: '82%',
                    height: '75%',
                    left: '5%',
                    label: {
                        normal: {
                            position: 'inside',
                            formatter: '{b}',
                            textStyle: {
                                color: '#fff'
                                }
                        },
                        emphasis: {
                            position:'inside',
                            formatter: '{c}%'
                        }
                    },
                    data:[
                        {value: 40, name:'A'},
                        {value: 50, name:'B'},
                        {value: 60, name:'C'},
                        {value: 80, name:'D'},
                        {value: 90, name:'E'}
                    ]
                },
                
            },
            depData:{
                custCount:[
                    
                ]
            },
            staffData:{
                custCount:{
                   
                },
            }
        }
    }
}