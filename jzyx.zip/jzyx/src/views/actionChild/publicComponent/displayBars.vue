<template>
    <div class="bars">
      <span>&nbsp;&nbsp;&nbsp;</span>
      <span v-show="countSum" class="el-icon-success" style="color:#409EFF"></span>
      <span >共 </span>
      <span class="red">{{countSum}}</span>
      <span> {{msg}}</span>
    </div>
</template>

<script>
    export default {
      name: "displayBars",
      props:['countSum','msg']
    }
</script>

<style scoped>
  .bars{
    display: inline-block;
  }
</style>
