export default {
  name: "action_tit",
  props:["title"],
  data(){
    return{
      toPagenData:[
        {
          title:"积分流水",
          name:"user",
          isSelect:false,
          value:0,
          icon:"fa fa-pie-chart",
        },
        {
          title:"权限管理",
          name:"authority",
          isSelect:false,
          value:0,
          icon:"fa fa-cog",
        },
        {
          title:"员工管理",
          name:"management",
          isSelect:false,
          value:0,
          icon:"fa fa-user",
        },
        {
          title:"部门管理",
          name:"management",
          isSelect:false,
          value:1,
          icon:"fa fa-th",
        },
        {
          title:"退出登录",
          name:"login",
          isSelect:false,
          value:0,
          icon:"fa fa-close",
        },
      ],
      data:"",
      pageName:"规则筛选",
      userNav:false,
    }
  },
  computed:{
    getUser(){
      return this.$store.state.user
    }
  },
  methods:{
    select:function(e){
      console.log(e);
    },
    quit:function(){
      localStorage['id'] = "";
      localStorage[this.codeKey] = "";
      this.$router.push({ name:'login'});
    },
    //保留两位小数
    toDecimal2:function (x){
      return x;
    }
  },
}
