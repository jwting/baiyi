<template>
  <div>
    <div v-for="v in data" v-if="v.radio==radio">
      <el-pagination
        v-if="v.countSum>10"
        style="text-align: right;margin-top: 20px"
        :background="true"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="v.row"
        :current-page.sync="v.pageNumber"
        :pager-count="7"
        layout="total, sizes, prev, pager, next, jumper"
        :total="v.countSum">
      </el-pagination>
    </div>
  </div>
</template>

<script>
    export default {
      name: "pageComponent",
      props:["radio","data"],
      data(){
        return{}
      },
      methods:{
        handleSizeChange:function (row) {
          for (var v of this.data){
            if(v.radio==this.radio){
              v.row = row;
            }
          }
          this.$emit('size-change',v)
        },
        handleCurrentChange:function (v) {
          this.$emit('current-change',v)
        }
      },
      created(){
        // console.log(this.radio);
      }
    }
</script>

<style scoped>

</style>
