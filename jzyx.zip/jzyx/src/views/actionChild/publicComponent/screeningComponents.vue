<template>
  <div>
    <div>
      <el-row class="scr-conlist">
        <el-col class="col" :span="5">条件筛选：</el-col>
        <el-col class="cocol" :span="18">
          <el-select style="width: 130px" v-model="type" @change="slelctChange" placeholder="请选择">
            <el-option
              v-for="item in (target=='queryCues')?data.submersible:data.clue"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <el-input v-if="type!='custType'" placeholder="请输入搜索内容" v-model="repData[type]" class="input-with-select">
          </el-input>
          <el-select v-else style="width: 200px"  v-model="repData.custType" placeholder="请选择">
            <el-option
              v-for="item in custTypeData"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-col>
      </el-row>
      <el-row class="scr-conlist" v-if="target=='queryCues'">
        <el-col class="col" :span="5">注册时间：</el-col>
        <el-col class="cocol" :span="18">
          <time-query v-model="repData.time" :quick-btn="false" time-type="ordinary" range-separator="至"></time-query>
        </el-col>
      </el-row>
      <el-row class="scr-conlist" v-if="target=='querySubmersible'">
        <el-col class="col" :span="5">跟进时间：</el-col>
        <el-col class="cocol" :span="18">
          <time-query v-model="repData.followTime" time-type="ordinary" range-separator="至"></time-query>
        </el-col>
      </el-row>
      <el-row class="scr-conlist" v-if="target=='querySubmersible'">
        <el-col class="col" :span="5">触达时间：</el-col>
        <el-col class="cocol" :span="18">
          <time-query v-model="repData.touchTime" time-type="ordinary" range-separator="至"></time-query>
          <!--<el-date-picker-->
            <!--v-model="r"-->
            <!--type="daterange"-->
            <!--range-separator="至"-->
            <!--value-format="yyyy-MM-dd"-->
            <!--start-placeholder="开始日期"-->
            <!--end-placeholder="结束日期">-->
          <!--</el-date-picker>-->
        </el-col>
      </el-row>
    </div>
    <div style="margin-top: 25px">
      <el-button type="primary" @click="pushData" icon="el-icon-refresh">开始查询</el-button>
      <el-button type="danger" @click="deleteData" icon="el-icon-delete">清空条件</el-button>
    </div>
  </div>
</template>

<script>
    export default {
        name: "screeningComponents",
        props:{
          data:null,
          target:null,
          userId:{
            default:window.localStorage['id']
          },
          deptId:{
            default:""
          }
        },
        data(){
          return{
            custTypeData:[
              {
                value: 'A',
                label: 'A:成单'
              }, {
                value: 'B',
                label: 'B:有兴趣'
              }, {
                value: 'C',
                label: 'C:暂无需求'
              }, {
                value: 'D',
                label: 'D:不感兴趣/挂电话'
              }, {
                value: 'E',
                label: 'E:接不通'
              }
            ],
            type:"companyName",
            repData: {
              followTime:'',
              touchTime:"",
              time:'',
              companyName:"",//公司名
              address:"",//地址
              operation:"",//行业
              custType:"",  //意向类型
              deptName:"",
              userId:this.userId,
              deptId:this.deptId
            }
          }
        },
        watch:{
          target:function () {
            this.type = "companyName";
            this.deleteData();
          }
        },
        methods:{
          slelctChange:function(){
            this.repData.companyName = "";
            this.repData.address = "";
            this.repData.operation = "";
            this.repData.custType = "";
            this.repData.deptName = "";
          },
          deleteData:function(){
            this.repData = {
              followTime:'',
              touchTime:"",
              time:'',
              companyName:"",//公司名
              address:"",//地址
              operation:"",//行业
              custType:"",  //意向类型
              deptName:"",
              userId:this.userId,
              deptId:this.deptId
            }
          },
          pushData:function () {
            console.log(this.repData)
            var data = {};
            for (var i in this.repData){
              if(this.repData[i]&&(typeof(this.repData[i]))!='object'){
                data[i] = this.repData[i];
              }else if(i=='time'&&this.repData[i][0]&&this.repData[i][1]){
                data["beginTime"] = this.repData[i][0];
                data["endTime"] = this.repData[i][1];
              }else if(i=='followTime'&&this.repData[i][0]&&this.repData[i][1]){
                data["lastStartDate"] = this.repData[i][0];
                data["lastEndDate"] = this.repData[i][1];
              }else if(i=='touchTime'&&this.repData[i][0]&&this.repData[i][1]){
                data["firstStartDate"] = this.repData[i][0];
                data["firstEndDate"] = this.repData[i][1];
              }
            }
            this.$emit('upload',data);
          }
        }
    }
</script>

<style scoped>
  .scr-conlist{
    color: #909399;
    height: 50px;
    line-height: 50px;
    border: 1px solid #ebeef5;
    border-bottom: none;
    box-sizing: border-box;
  }
  .scr-conlist:last-child{
    border-bottom:1px solid #ebeef5 !important;
  }
  .col{
    text-align: center;
    font-weight: 600;
    font-size: 15px;
    background: #FAFAFA;
    border-right:  1px solid #ebeef5;
  }
  .col:last-child{
    border-bottom:1px solid #ebeef5;
  }
  .cocol{
    padding-left: 35px;
    color: #909399;
    height: 100%;
  }
  .input-with-select{
    width: 300px;
  }
</style>
