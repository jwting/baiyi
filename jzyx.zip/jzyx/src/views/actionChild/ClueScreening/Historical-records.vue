<template>
    <div class="action_child">
      <action_tit title="筛选历史"></action_tit>
      <el-row class="tit-row">
        <el-col :span="3"><div>日期</div></el-col>
        <el-col :span="6"><div class="left">条件</div></el-col>
        <el-col :span="6"><div class="center">策略备注</div></el-col>
        <el-col :span="4"><div class="center">结果数</div></el-col>
        <el-col :span="5" class="right"><div>操作</div></el-col>
      </el-row>
      <el-row class="act-row ls" v-for="(v,index) in resData.data" :key="index">
        <el-col :span="3"><div>{{v.date}}</div></el-col>
        <el-col :span="6">
          <!--策略详情弹窗-->
          <el-popover
            placement="right"
            width="400"
            trigger="hover">
            <div style="line-height: 26px">
              <div style="font-weight: 600;font-size: 15px;color: #000">{{v.logicValue==1?"符合以下全部":"符合其中一个"}}</div>
              <div v-for="(item,i) in v.condition" :key="i">
                <span style="font-weight: 600">{{item.field+":"}}&nbsp;</span>
                <span v-if="item.type!=3&&item.type!=4">{{item.fieldLogic==1?"符合全部":(item.fieldLogic==2)?"符合其中一个":((item.fieldLogic==3)?"符合全部才排除":"符合一个就排除")}}&nbsp</span>
                <span v-if="item.type==3">{{(item.fieldLogic==1)?"是":"否"}}</span>
                <span v-if="item.type==2">
                  <span v-for="(value,k) in item.conditions.split(',')" :key="k">
                    <span>{{value.indexOf('and')==-1?value+item.unit:'介于'+value.split('and')[0]+item.unit+'-'+value.split('and')[1]+item.unit}}&nbsp;</span>
                    <span v-show="k!=item.conditions.split(',').length-1">{{item.fieldLogic==1?"且":"或"}}&nbsp;</span>
                  </span>
                </span>
                <span v-show="item.type==1">{{item.conditions}}</span>
                <span v-if="item.type==4">{{item.conditions.toString().replace(/[\[\]]/g,"")}}</span>
              </div>
            </div>
            <div class="left pointer" slot="reference">
              <div>{{v.logicValue==1?"符合以下全部":"符合其中一个"}}</div>
              <div v-for="(item,i) in v.condition" :key="i">
                <span>{{item.field+":"}}&nbsp;</span>
                <span v-if="item.type!=3&&item.type!=4">{{item.fieldLogic==1?"符合全部":(item.fieldLogic==2)?"符合其中一个":((item.fieldLogic==3)?"符合全部才排除":"符合一个就排除")}}&nbsp</span>
                <span v-if="item.type==3">{{(item.fieldLogic==1)?"是":"否"}}</span>
                <span v-if="item.type==2">
                  <span v-for="(value,k) in item.conditions.split(',')" :key="k">
                    <span>{{value.indexOf('and')==-1?value+item.unit:'介于'+value.split('and')[0]+item.unit+'-'+value.split('and')[1]+item.unit}}&nbsp;</span>
                    <span v-show="k!=item.conditions.split(',').length-1">{{item.fieldLogic==1?"且":"或"}}&nbsp;</span>
                  </span>
                 </span>
                <span v-show="item.type==1">{{item.conditions}}</span>
                <span v-if="item.type==4">{{item.conditions.toString().replace(/[\[\]]/g,"")}}</span>
              </div>
            </div>
          </el-popover>
        </el-col>
        <el-col :span="6" class="center"><div>{{v.strategyName}}</div></el-col>
        <el-col :span="4" class="center"><div>{{v.number}}</div></el-col>
        <el-col :span="5" class="right">
          <div>
            <el-button type="primary" @click="ImportStrategy(index)">导入</el-button>
            <el-button type="danger" @click="delectStrategy(v.strategyName,index)">删除</el-button>
          </div>
        </el-col>
      </el-row>
      <!--底部分页-->
      <div>
        <el-pagination
          v-show="resData.countSum>10"
          style="text-align: right;margin-top: 20px"
          :background="true"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="10"
          :pager-count="7"
          layout="total, sizes, prev, pager, next, jumper"
          :total="resData.countSum">
        </el-pagination>
      </div>
    </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
      name: "Historical-records",
      components: {Action_tit},
      data(){
          return{
            repData:{
              rows:"10",
              pageNumber:"1",
              userId:""
            },
            userId:"",
            resData:{}
          }
        },
        methods:{
          //导入历史策略
          ImportStrategy:function(index){
            var value = {
              condition:this.resData.data[index].condition,
              strategyName:this.resData.data[index].strategyName,
              logicValue:this.resData.data[index].logicValue
            };
            this.$router.push({ name: 'screening',params:{value:value}});
          },
          //用户改变每页显示条数
          handleSizeChange:function(e){
            this.repData.rows = e;
            this.getHistorcal();
          },
          //用户改变页数
          handleCurrentChange:function(e){
            this.repData.pageNumber = e;
            this.getHistorcal();
          },
          //删除策略
          delectStrategy:function (e,index) {
            var that = this;
            this.$confirm('此操作将永久删除该策略, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.axios({
                method: 'get',
                url: this.host + "historyStrategy/deleteHistoryStrategy?strategyName="+e+"&userId="+this.userId,
              }).then(function (res) {
                that.$message({
                  type: 'success',
                  message: '删除成功!'
                });
                that.resData.data.splice(index,1);
              })
            }).catch(() => {
              that.$message({
                type: 'info',
                message: '已取消删除'
              });
            });
          },
        //获取历史策略
        getHistorcal:function() {
          var that = this;
          var data = that.repData;
          var url = 'historyStrategy/queryHistoryStrategy?pageNumber='+data.pageNumber+'&rows='+data.rows+'&userId='+data.userId;
          that.axios({
            method: 'get',
            url: that.host + url,
          }).then(function (res) {
            for (var v of res.data.data){
              for (var item of v.condition){
                if (item.type==4){
                  item.conditions = item.conditions.toString().replace(/[\[\]]/g,"").split(',');
                }
              }
            }
            that.resData = res.data;
          })
          },
        },
        created:function () {
          this.userId = window.localStorage["id"];
          this.repData.userId = window.localStorage["id"];
          this.getHistorcal();
        }

    }
</script>

<style scoped>
  .pointer{
    cursor: pointer;
    width: 100%;
    height: 50px;
  }
  .ls{
    height: 140px;
    line-height: 25px;
    overflow: hidden;
    padding: 10px 0;
  }
</style>
