<template>
    <div class="action_child" style="min-height: 500px;border-radius: 8px">
      <action_tit title="权限管理"></action_tit>
      <!--<div class="tit-text">权限管理</div>-->
      <!--修改-->
      <div style="margin-bottom: 20px">
        <el-button :disabled="true" type="success" icon="el-icon-setting">修改</el-button>
        <el-button :disabled="true" type="primary" icon="el-icon-plus">添加</el-button>
        <el-button :disabled="true" type="danger" icon="el-icon-delete">删除</el-button>
        <span class="ti">该功能暂不可用</span>
      </div>
      <!--修改权限列表弹窗-->
      <el-dialog
        :visible.sync="isAuthorityManagement"
        width="400px"
        :center="true"
        top="15vh"
        style="text-align:left;font-size: 12px;border-radius: 6px;">
        <div style="height: 300px;overflow: auto">
          <permission-tree :tree-data="authorityManagement"></permission-tree>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button @click="isAuthorityManagement = false">取 消</el-button>
            <el-button type="primary" @click="updataSionsList">确 定</el-button>
        </span>
      </el-dialog>

      <!--权限列表-->
      <el-table
        :data="roleList.data"
        style="width: 100%;margin: 0 auto;"
        border
      >
        <el-table-column prop="roleName" label="角色名" align="center"></el-table-column>
        <el-table-column prop="description" label="角色说明" align="center"></el-table-column>
        <el-table-column prop="roleName" align="center" label="设置">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row.id)"  type="text" size="small"><span class="el-icon-setting"></span></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    import PermissionTree from "../publicComponent/permissionTree";
    export default {
      name: "authority",
      data(){
        return{
          defaultExpanded:[],
          defaultChecked:[],
          defaultProps: {
            children: 'children',
            label: 'permissionName'
          },
          isId:"",
          roleId:"",
          isAuthorityManagement:false,
          //角色列表
          roleList:{},
          //权限列表
          authorityManagement:[]
        }
      },
      methods:{
        //修改角色权限弹窗
        handleClick:function(e){
          var that = this;
          that.roleId = e;
          that.axios({
            method: 'post',
            url: that.host+'permission/getRolePermission',
            data:{
              id:e,
            },
          }).then(function (res){
            that.authorityManagement = res.data.data;
            that.isAuthorityManagement = true;
          });
          this.isId = e;
        },
        //提价权限修改
        updataSionsList:function(){
          var that = this;
          that.axios({
            method: 'post',
            url: that.host+'permission/updateRolePermission',
            data:{
              roleId:that.roleId,       //角色ID
              lists:that.authorityManagement
            },
          }).then(function (res){
            if(res.data.status==200){
              that.isAuthorityManagement = false;
              that.$message({
                message: res.data.msg,
                type: 'success'
              });
            }else {
              that.$message.error(res.data.msg);
            }
          });
        },
      },
      components: {PermissionTree, Action_tit},
      created:function () {
        var that = this;
        that.axios({
          method: 'post',
          data:{
            cId:window.localStorage['cId'],       //公司ID
          },
          url: that.host+'permission/getCompanyRoles',
        }).then(function (res){
          that.roleList = res.data;
          console.log(res.data);
        });
      }
    }
</script>

<style scoped>
</style>
