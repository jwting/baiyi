<template>
    <div class="action_child">
      <action_tit title="积分流水"></action_tit>
      <el-row type="flex" justify="end" :gutter="20">
        <el-col :span="2"><el-button class="btn" @click="exportIntegralExcel" type="primary" >导出</el-button></el-col>
      </el-row>
      <el-row class="tit-row">
        <el-col :span="3"><div>日期</div></el-col>
        <el-col :span="3"><div class="center">类型</div></el-col>
        <el-col :span="6"><div class="center">操作账号</div></el-col>
        <el-col :span="6"><div class="center">备注</div></el-col>
        <el-col :span="3" class="center"><div>线索数量</div></el-col>
        <el-col :span="3" class="right"><div>积分</div></el-col>
      </el-row>
      <el-row class="act-row" v-for="(v,k) in resData.data">
        <el-col :span="3"><div>{{timestampToTime(v.createTime)}}</div></el-col>
        <el-col :span="3"><div class="center">{{v.type==0?"筛选":v.type==1?"智能":v.type==2?"充值":v.type==3?"导出":"未知"}}</div></el-col>
        <el-col :span="6"><div class="center">{{v.operatorUser}}</div></el-col>
        <el-col :span="6"><div class="center">{{v.remark}}</div></el-col>
        <el-col :span="3" class="center"><div>{{v.number?v.number:"/"}}</div></el-col>
        <el-col :span="3" class="right"><div>{{toDecimal2(v.integral).indexOf("-") != -1 ? toDecimal2(v.integral):"+"+toDecimal2(v.integral)}}</div></el-col>
      </el-row>
      <!--分页-->
      <div>
        <el-pagination
          v-show="resData.countSum>10"
          style="text-align: right;margin-top: 20px"
          :background="true"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="10"
          :pager-count="7"
          layout="total, sizes, prev, pager, next, jumper"
          :total="resData.countSum">
        </el-pagination>
      </div>
      <el-row style="margin-top: 40px">
        <el-col :span="8">充值请联系客服经理 {{managerName}}：{{phone}}</el-col>
        <el-col :span="16" class="right">
          <span>累计充值&nbsp;&nbsp;</span>
          <span>{{accumulatedRecharge}}&nbsp;&nbsp;&nbsp;&nbsp;</span>
          <span>累计消耗&nbsp;&nbsp;</span>
          <span>{{cumulativeConsumption}}&nbsp;&nbsp;&nbsp;&nbsp;</span>
          <span>当前剩余&nbsp;&nbsp;</span>
          <span>{{integral}}&nbsp;&nbsp;&nbsp;&nbsp;</span>
        </el-col>
      </el-row>
    </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
      name: "user",
      components: {Action_tit},
      data(){
          return{
            accumulatedRecharge:"",
            cumulativeConsumption:"",
            integral:"",
            managerName:"",
            phone:"",
            pageNumber:"1",
            rows:"10",
            userId : window.localStorage["id"],
            resData:{}
          }
        },
        userData: {},
        methods:{
          //用户改变每页显示条数
          handleSizeChange:function(e){
            this.rows = e;
            this.getHistorcal();
          },
          //用户改变页数
          handleCurrentChange:function(e){
            this.pageNumber = e;
            this.getHistorcal();
          },
          //保留两位小数
          toDecimal2:function (x){
              var f = Math.round(x * 100)/100;
              var s = f.toString();
              var rs = s.indexOf('.');
              if(rs<0){
                rs=s.length;s+='.';
              }
              while(s.length<=rs+2){
                s+='0';
              }
              return s;
          },
          //导出积分excel
          exportIntegralExcel:function(){
            this.axios({
              method: 'get',
              url: this.host+'integral/export?userId='+this.userId,
            }).then(response => {
              this.urlDownload(response.data.data.FileUrl)
            }).catch((error) => {
              alert("导出失败！");
            })
          },
          //获取积分列表
          getHistorcal:function(){
            this.axios({
              method : 'get',
              url: this.host+'integral/queryAll?userId='+this.userId+'&pageNumber='+this.pageNumber+'&rows='+this.rows,
            }).then(res=>{
              this.resData= res.data;
            })
          },
        },
        created:function () {
          this.getHistorcal();
          this.axios({
            method: 'get',
            url: this.host+'user/tokenGetUser?userId='+window.localStorage['id'],
          }).then(res=>{
            if(res.data.status==200){
              this.accumulatedRecharge = res.data.data.accumulatedRecharge;
              this.cumulativeConsumption = res.data.data.cumulativeConsumption;
              this.integral = res.data.data.integral;
              this.managerName = res.data.data.managerName;
              this.phone = res.data.data.phone;
            }
          });

        }
    }
</script>

<style scoped>


</style>
