<template>
  <div class="action_child" style="padding-bottom: 100px">
      <action_tit :title="pageValue==1?'部门管理':'员工管理'"></action_tit>
      <!--添加或修改员工按钮-->
      <div style="margin-bottom: 5px">
        <el-button type="primary" @click="isPermissionsList=true;isUpdata=false" icon="el-icon-plus">{{pageValue==1?"添加部门":"添加员工"}}</el-button>
        <el-select v-if="pageValue==0" style="width: 150px;margin-left: 20px" v-model="repData.type" placeholder="选择搜索条件">
          <el-option
            v-for="item in searchList"
            :label="item.lable"
            :value="item.value"
            :key="item.value"
          >
          </el-option>
        </el-select>
        <el-input v-if="pageValue==0" placeholder="请输入搜索内容" @clikc="toSearch" v-model="repData.value" class="input-with-select">
          <el-button slot="append" style="width: 50px;padding: 0" @click="toSearch" icon="el-icon-search"></el-button>
        </el-input>
        <span v-if="pageValue==1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;一共 <span class="danger" style="font-weight: 600">{{departmentList?departmentList.data.length:0}}</span> 条记录</span>
        <span v-if="pageValue==0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;一共 <span class="danger" style="font-weight: 600">{{employeeList.countSum}}</span> 条记录</span>
      </div>
      <div v-if="pageValue==0">
        <span style="margin-left: 0;margin-bottom: 20px" class="ti">
          温馨提示！
          员工账号被注销后，可通过更改状态恢复。合并账号未被选择的被合并账号线索，进入公司线索池
        </span>
      </div>
      <div v-if="pageValue==1">
          <span style="margin-left: 0;margin-bottom: 20px" class="ti">
            温馨提示！
            删除部门需要先移除该部门下所有员工
          </span>
      </div>
      <!--修改或添加员工信息弹窗-->
      <el-dialog
        :visible.sync="isPermissionsList"
        width="400px"
        :center="true"
        style="text-align:left;font-size: 12px;border-radius: 6px;">
        <div v-if="pageValue==0">
          <el-row class="lin">
            <el-col :span="5"><span class="danger">*</span><span>员工姓名:</span></el-col>
            <el-col :span="19">
              <el-input v-model="pushEmployee.nickName"></el-input>
            </el-col>
          </el-row>
          <el-row class="lin">
            <el-col :span="5"><span class="danger">*</span><span>用户名:</span></el-col>
            <el-col :span="19">
              <el-input v-model="pushEmployee.userName"></el-input>
            </el-col>
          </el-row>
          <el-row class="lin">
            <el-col :span="5"><span class="danger">*</span><span>密码:</span></el-col>
            <el-col :span="19">
              <el-input v-model="pushEmployee.password" type="password"></el-input>
            </el-col>
          </el-row>
          <el-row class="lin">
            <el-col :span="5"><span class="danger">*</span><span>部门:</span></el-col>
            <el-col :span="19">
              <el-select style="width: 100%" v-model="pushEmployee.dId" placeholder="请选择部门">
                <el-option
                  v-for="item in departmentList.data"
                  :key="item.id"
                  :label="item.deptName"
                  :value="item.id"
                >
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row class="lin" v-if="pushEmployee.role.id!='2'">
            <el-col :span="5"><span class="danger">*</span><span>角色:</span></el-col>
            <el-col :span="19">
              <el-select style="width: 100%" v-model="pushEmployee.role.id" placeholder="请选择角色">
                <el-option
                  v-for="item in roleList.data"
                  :key="item.id"
                  :label="item.roleName"
                  :value="item.id"
                  >
                </el-option>
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div v-if="pageValue==1">
          <el-row class="lin">
            <el-col :span="5"><span class="danger">*</span><span>部门名称:</span></el-col>
            <el-col :span="19">
              <el-input v-model="pushDepartment.deptName"></el-input>
            </el-col>
          </el-row>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button @click="isPermissionsList = false">取 消</el-button>
            <el-button type="primary" @click="updataSionsList">确 定</el-button>
        </span>
      </el-dialog>
      <!--合并员工弹窗-->
      <el-dialog
        :visible.sync="isMergedEmployees"
        width="400px"
        :center="true"
        v-if="pageValue==0"
        style="text-align:left;font-size: 12px;border-radius: 6px;">
        <div>
          <el-row class="lin">
            <el-col :span="6"><span class="danger">*</span><span>合并员工:</span></el-col>
            <el-col :span="18">
              <el-input v-model="mergedEmployees.nickName"></el-input>
            </el-col>
          </el-row>
          <el-row class="lin">
            <el-col :span="6"><span class="danger">*</span><span>被合并员工:</span></el-col>
            <el-col :span="8">
              <el-select style="width: 90%" v-model="nubEmployee" placeholder="请选择部门">
                <el-option
                  v-for="item in departmentList.data"
                  :key="item.id"
                  :label="item.deptName"
                  :value="item.id"
                >
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="10">
              <el-select style="width: 100%" v-model="mergedEmployees.aimsId" placeholder="请选择员工">
                <el-option
                  :disabled="item.id==mergedEmployees.id"
                  v-for="item in departmentEmployee.data"
                  :label="item.nickName"
                  :value="item.id"
                  :key="item.id"
                >
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row class="lin">
            <el-col :span="6"><span class="danger">*</span><span>选择:</span></el-col>
            <el-col :span="18">
              <el-checkbox label="潜客" v-model="mergedEmployees.submarine"></el-checkbox>
              <el-checkbox label="线索" v-model="mergedEmployees.clue"></el-checkbox>
            </el-col>
          </el-row>
        </div>
        <span slot="footer" class="dialog-footer">
              <el-button @click="isMergedEmployees = false">取 消</el-button>
              <el-button type="primary" @click="pushMergedEmployees">确 定</el-button>
          </span>
      </el-dialog>
      <!--员工表-->
      <el-table
        :data="employeeList.data"
        style="width: 100%;margin: 0 auto;"
        border
        v-if="pageValue==0"
        key="111155"
      >
        <el-table-column prop="nickName" label="员工名称" align="center"></el-table-column>
        <el-table-column prop="deptName" align="center" label="部门"></el-table-column>
        <el-table-column prop="userName" label="手机账号" align="center"></el-table-column>
        <el-table-column prop="roleName" align="center" label="角色"></el-table-column>
        <el-table-column align="center" label="最后登录时间">
          <template slot-scope="scope">
            <span>{{timestampToTime(scope.row.loginTime)}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="状态">
          <template slot-scope="scope">
            <el-select @change="selectChange(scope.row.status,scope.row.id)" style="width: 80%;" v-model="scope.row.status"  placeholder="请选择转态">
              <el-option
                :disabled="item.id==mergedEmployees.id"
                v-for="item in statusData"
                :label="item.lable"
                :value="item.value"
                :key="item.value"
              >
              </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column align="center" label="线索池数量">
          <template slot-scope="scope">
            <router-link class="color" :to="{name:'myClue',query:{value:scope.row.id,radio:'queryCues'}}">
              {{scope.row.clueCount}}
            </router-link>
          </template>
        </el-table-column>
        <el-table-column align="center" label="潜客池数量">
          <template slot-scope="scope">
            <router-link class="color" :to="{name:'myClue',query:{value:scope.row.id,radio:'querySubmersible'}}">
              {{scope.row.submarineCount}}
            </router-link>
          </template>
        </el-table-column>
        <el-table-column align="center" label="设置">
          <template slot-scope="scope">
            <el-button @click="updataXin(scope.row)" type="text">编辑</el-button>
            <el-button type="text"
                       @click="isMergedEmployees=true;
                       mergedEmployees.id=scope.row.id;
                       mergedEmployees.nickName=scope.row.nickName;"
                       style="color: #F56C6C">
                       合并
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--部门表-->
      <el-table
        :data="departmentList.data"
        style="width: 100%;margin: 0 auto;"
        border
        v-if="pageValue==1"
        key="1111544"
      >
        <el-table-column prop="deptName" label="部门名称" align="center"></el-table-column>
        <el-table-column align="center" label="部门经理">
          <template slot-scope="scope">
            <span>{{scope.row.deptManagerName?scope.row.deptManagerName:'/'}}</span>
          </template>
        </el-table-column>
        <el-table-column label="线索池数量" align="center">
          <template slot-scope="scope">
            <router-link class="color" :to="{name:'departmentalClues',query:{value:scope.row.id,radio:'queryCues'}}">
              {{scope.row.clueCount?scope.row.clueCount:'0'}}
            </router-link>
          </template>
        </el-table-column>
        <el-table-column label="潜客池数量" align="center">
          <template slot-scope="scope">
            <router-link class="color" :to="{name:'departmentalClues',query:{value:scope.row.id,radio:'querySubmersible'}}">
              {{scope.row.submarineCount?scope.row.submarineCount:'0'}}
            </router-link>
          </template>
        </el-table-column>
        <el-table-column align="center" label="员工数量">
          <template slot-scope="scope">
            <span>{{scope.row.staffCount?scope.row.staffCount:'/'}}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="设置">
          <template slot-scope="scope">
            <el-button type="text"
             @click="isPermissionsList=true;
             isUpdata=true;
             pushDepartment.id=scope.row.id;
             pushDepartment.deptName=scope.row.deptName"
            >编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--分页-->
      <div v-if="pageValue==0" style="width: 60%;float: right">
        <el-pagination
          v-if="employeeList.countSum>10"
          style="text-align: right;margin-top: 20px"
          :background="true"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :page-sizes="[10, 20, 50, 100]"
          :current-page.sync="repData.pageNumber"
          :page-size="repData.rows"
          :pager-count="7"
          layout="total, sizes, prev, pager, next, jumper"
          :total="employeeList.countSum">
        </el-pagination>
      </div>
  </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
        name: "management",
        data(){
          return{
            repData:{
              id:window.localStorage['id'],
              value:"",
              type:0,
              rows:10,
              pageNumber:1,
            },
            nubEmployee:"",
            searchList:[
              {
                value:0,
                lable:"全部"
              },
              {
                value:1,
                lable:"员工姓名"
              },
              {
                lable:"部门",
                value:2,
              },
              {
                value:3,
                lable:"账号"
              },
            ],
            statusData:[
              {
                value:0,
                lable:"正常"
              },
              {
                value:1,
                lable:"被注销"
              }
            ],
            mergedEmployees:{
              id:"",       //员工ID
              aimsId:"",    //目标员工ID
              clue:false,    //线索   true  &&  false
              submarine:false   //潜客   true  &&  false
            },
            //角色列表
            roleList:{
                
            },
            isMergedEmployees:false,
            //是否为上传
            isUpdata:false,
            //搜索框内容
            searchData:{
              cId:"",    //公司ID
              type:"userName",
              value:"",
            },
            //当前页面是否是员工页面
            pageValue:"",
            //添加或编辑弹窗控制
            isPermissionsList:false,
            //添加员工信息
            pushEmployee:{
              id:"",
              userName:"",   //用户名
              nickName:"",   //中文名
              password:"",    //密码
              dId:"",    //部门ID
              role:{
                id:""
              }   //角色ID
            },
            //添加部门
            pushDepartment:{
              deptName:"",   //部门名称
              aId:window.localStorage['id'],   //用户ID
              id:"",   //部门ID
            },
            //部门数据
            departmentList:{
              data:[]
            },
            //部门下员工
            departmentEmployee:{

            },
             //员工数据
            employeeList:{},
            //选择列表
            editList:[],
         }
        },
        watch:{
          '$route':function (to, from){
            this.pageValue = this.$route.params.value;
            this.getpageValue(this.pageValue);
          },
          nubEmployee:function () {
            var that = this;
            console.log(this.nubEmployee);
            that.axios({
              url:this.host+'user/searchDeptEmployee',
              method: 'post',
              data:{
                id:this.nubEmployee
              }
            }).then(function (res){
              that.departmentEmployee = res.data
            })
          }
        },
        components: {Action_tit},
        methods:{
          //删除部门
          deleteDepartment:function(id,index){
            var that = this;
            this.$confirm('此操作将删除此部门, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.axios({
                method: 'post',
                data:{
                  id:id
                },
                url: this.host + "dept/del",
              }).then(function (res) {
                if(res.data.status==200){
                  that.departmentList.data.splice(index,1);
                  that.$message({
                    message: res.data.msg,
                    type: 'success'
                  });
                }else {
                  that.$message.error(res.data.msg);
                }
              })
            }).catch(() => {
              this.$message({
                type: 'info',
                message: '已取消'
              });
            });
          },
          //更改账号状态
          selectChange:function(e,id){
            var that = this;
            this.axios({
              method: 'post',
              data:{
                id:id,
                status:e
              },
              url: this.host + "user/cancellation",
            }).then(function (res) {
              if(res.data.status==200){
                that.getEmployeeList();
                that.$message({
                  message: res.data.msg,
                  type: 'success'
                });
              }else {
                that.$message.error(res.data.msg);
              }

            })
          },
          //合并员工
          pushMergedEmployees:function(){
            var that = this;
            this.axios({
              method: 'post',
              data:this.mergedEmployees,
              url: this.host + "user/mergeEmployee",
            }).then(function (res) {
              if(res.data.status==200){
                that.getEmployeeList();
                that.isMergedEmployees = false;
                that.$message({
                  message: res.data.msg,
                  type: 'success'
                });
              }else {
                that.$message.error(res.data.msg);
              }

            })
          },
          //编辑信息
          updataXin:function(v){
            var that = this;
            this.isUpdata = true;
            this.axios({
              method: 'post',
              data:{
                id:v.id
              },
              url: this.host + "user/getUserDeatils",
            }).then(function (res) {
              that.pushEmployee = {
                id:v.id,   //用户名
                nickName:res.data.data.nickName,   //中文名
                userName:res.data.data.userName,
                password:res.data.data.password,    //密码
                dId:res.data.data.dId,      //公司ID
                role:{
                  id:res.data.data.role.id  //角色ID
                },
              };
              that.isPermissionsList = true;
            })
           },
          //注销或删除
          deleteList:function(){
            var that = this;
            this.$confirm('此操作将删除或注销记录, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              console.log('dad');
              // that.axios({
              //   method: 'post',
              //   data:{
              //     id:""
              //   },
              //   url: this.host + url,
              // }).then(function (res) {
              //
              // })
            }).catch(() => {
              this.$message({
                type: 'info',
                message: '已取消'
              });
            });
          },
          //搜索
          toSearch:function(){
            this.repData.pageNumber = 1;
            this.getEmployeeList();
          },
          //添加修改员工或部门
          updataSionsList:function(){
            var that = this;
            //更新部门
            if(this.isUpdata&&this.pageValue==1){
              var data = this.pushDepartment;
              var url = "dept/update";
            //添加部门
            }else if(!this.isUpdata&&this.pageValue==1){
              var data = {
                aId:this.pushDepartment.aId,
                deptName:this.pushDepartment.deptName
              };
              var url = "dept/createDept";
            //添加员工
            }else if(!this.isUpdata&&this.pageValue==0){
              var data = this.pushEmployee;
              var url = "user/addStaff";
            //添加员工
            }else if(this.isUpdata&&this.pageValue==0){
              var data = this.pushEmployee;
              var url = "user/updateStaff";
            }
            //ajax处理
            this.axios({
              method: 'post',
              data:data,
              url: this.host + url,
            }).then(function (res) {
              that.isPermissionsList = false;
              if(res.data.status==200){
                if(that.pageValue==1){
                  that.getDepartmentList();
                }else if(that.pageValue==0){
                  that.getEmployeeList();
                }
                that.$message({
                  message: res.data.msg,
                  type: 'success'
                });
              }else {
                that.$message.error(res.data.msg);
              }
            });

          },
          //选择回调
          handleSelectionChange:function (e) {
            this.editList = e;
          },
          //用户改变每页显示条数
          handleSizeChange:function(e){
            this.repData.rows = e;
            this.getEmployeeList();
          },
          //用户改变页数
          handleCurrentChange:function(e){
            this.repData.pageNumber = e;
            this.getEmployeeList();
          },
          //获取员工列表
          getEmployeeList:function () {
            var that = this;
            this.axios({
              method: 'POST',
              data:this.repData,
              url: this.host + "user/searchEmployee",
            }).then(function (res) {
              that.employeeList = res.data;
            });
          },
          //获取部门列表
          getDepartmentList:function () {
            var that = this;
            this.axios({
              method: 'POST',
              data:{
                id:window.localStorage['cId']
              },
              url: this.host + "dept/searchDeptDeatil",
            }).then(function (res) {
              that.departmentList = res.data;
            });
          },
          //获取当前页面数据
          getpageValue:function (pageValue) {
            //判断页面参数  获取部门或员工列表 pageValue 1 部门 0 员工
            if(pageValue==1){
              this.getDepartmentList();
            }else if(pageValue==0){
              this.getEmployeeList();
              this.getDepartmentList();
              this.getRoleList();
            }
          },
          //获取角色列表
          getRoleList:function () {
            var that = this;
            this.axios({
              method: 'POST',
              data:{
                cId:window.localStorage['cId']
              },
              url: this.host + "permission/getCompanyRoles",
            }).then(function (res) {
              that.roleList = res.data;
            });
          }
        },
        created:function () {
          this.pageValue = this.$route.params.value;
          this.getpageValue(this.pageValue);
        }
    }
</script>

<style scoped>
  .input-with-select{
    width: 350px;
  }
  .lin{
    line-height: 32px;
    margin-bottom: 15px;
  }
</style>
