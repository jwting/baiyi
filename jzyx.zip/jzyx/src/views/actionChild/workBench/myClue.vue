<template>
  <div>
    <div class="action_child work-app-style">
      <action_tit :title="radio=='queryCues'?'我的线索':'我的潜客'"></action_tit>
      <div class="search-margin">
        <el-menu :default-active="radio" class="el-menu-demo" mode="horizontal" @select="handleSelect">
          <el-menu-item index="queryCues">我的线索</el-menu-item>
          <el-menu-item index="querySubmersible">我的潜客</el-menu-item>
        </el-menu>
      </div>
      <screening-components :user-id="userId()" :target="radio" @upload="pushData" :data="data"></screening-components>
    </div>
    <div  class="action_child">
      <div class="text-margin">
        <template v-if="myUserId==userId()">
          <el-button type="primary" @click="handleMobileClueis(false)" :disabled="this.selectRep.ids==''" v-if="radio=='queryCues'">移动选中</el-button>
          <el-button @click="handleMobileClueis(true)" type="primary" :disabled="myClueData.countSum==0" v-if="radio=='queryCues'">移动全部</el-button>
        </template>
        <display-bars
          :msg="radio=='queryCues'?'条线索':'条潜客'"
          :count-sum="radio=='queryCues'?myClueData.countSum:mySubmersibleData.countSum">
        </display-bars>
      </div>
      <!--录入潜客-->
      <el-dialog :visible.sync="enterTheSubmersible" :center="true" width="500px">
        <div>
          <el-row class="text-margin">
            <el-col :span="7"><span>客户意向等级:</span></el-col>
            <el-col :span="17">
              <el-select style="width: 160px" v-model="submersibleData.custType" placeholder="请选择">
                <el-option
                  v-for="item in Grade"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="7"><span>跟进记录:</span></el-col>
            <el-col :span="17">
              <el-input type="textarea" v-model="submersibleData.record"></el-input>
            </el-col>
          </el-row>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="enterTheSubmersible = false">取 消</el-button>
          <el-button type="primary" @click="joinRemarks">确 定</el-button>
        </span>
      </el-dialog>
      <!--选择移动条数与跟进人-->
      <el-dialog :visible.sync="isLookatThewHole" :center="true" width="400px">
        <div>
          <div v-if="isSelect">
            <div class="text-margin">
              <span>开始条数：&nbsp;&nbsp;</span>
              <el-input-number v-model="bars.min" style="margin-right: 30px"  :min="1" :max="radio=='queryCues'?myClueData.countSum:mySubmersibleData.countSum" label="开始条数"></el-input-number>
            </div>
            <div class="text-margin">
              <span>结束条数：&nbsp;&nbsp;</span>
              <el-input-number v-model="bars.max" :min="1" :max="radio=='queryCues'?myClueData.countSum:mySubmersibleData.countSum" label="结束条数"></el-input-number>
              <el-button style="margin-left: 10px" @click="bars.max=(radio=='queryCues'?myClueData.countSum:mySubmersibleData.countSum)" type="text">最大</el-button>
            </div>
          </div>
          <div>
            <span>跟进人：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <el-select style="width: 120px" v-model="selectRep.deptId" placeholder="选择部门">
              <el-option
                v-for="item in departData"
                :key="item.id"
                :label="item.deptName"
                :value="item.id">
              </el-option>
            </el-select>
            <el-select style="width: 120px; " v-model="selectRep.destId" placeholder="选择员工">
              <el-option
                v-for="item in ClueData"
                :key="item.id"
                :label="item.nickName"
                :value="item.id">
              </el-option>
            </el-select>
          </div>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="isLookatThewHole = false">取 消</el-button>
          <el-button type="primary" @click="ThewHole">确 定</el-button>
        </span>
      </el-dialog>
      <el-table
        v-if="radio=='queryCues'"
        key="4511616"
        :data="myClueData.data"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column label="公司名" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">公司名</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.companyName}}</div>
                <div slot="reference"><span class="color">{{scope.row.companyName}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="官网" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <a :href="scope.row.webSite.toString().indexOf('http')!=-1?scope.row.webSite:'http://'+scope.row.webSite" class="color" target="_blank">
                {{scope.row.webSite?scope.row.webSite:"/"}}
              </a>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="地址" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">地址</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.address}}</div>
                <div slot="reference"><span>{{scope.row.address}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="主营产品" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">主营产品</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.operation}}</div>
                <div slot="reference"><span>{{scope.row.operation}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="联系方式" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">联系方式</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.contactPhone}}</div>
                <div slot="reference"><span>{{scope.row.contactPhone}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="注册时间" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.createTime}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column  label="操作" align="center">
          <template slot-scope="scope">
            <el-button type="text" @click="goDetails(scope.row.id)">详情</el-button>
            <el-button v-if="myUserId==userId()" type="text" @click="enterTheSubmersible=true;submersibleData.companyId=scope.row.id">新增备注</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-table
        v-else
        key="4511617"
        :data="mySubmersibleData.data"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column label="公司名" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">公司名</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.companyName}}</div>
                <div slot="reference"><span class="color">{{scope.row.companyName}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="意向类型" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.custType}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="跟进记录" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">跟进记录</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.record}}</div>
                <div slot="reference"><span>{{scope.row.record}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="上次跟进时间" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.lastDate}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="触达时间" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.firstDate}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column  label="操作" align="center">
          <template slot-scope="scope">
            <el-button type="text" @click="goDetails(scope.row.companyId)">详情</el-button>
            <el-button type="text" @click="enterTheSubmersible=true;submersibleData.companyId=scope.row.companyId">新增备注</el-button>
            <el-button type="text" @click="sumDelete(scope.row.companyId)" class="danger">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <page-component
        :radio="radio"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :data="pageData">
      </page-component>
    </div>
  </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    import ScreeningComponents from "../publicComponent/screeningComponents";
    import DisplayBars from "../publicComponent/displayBars";
    import PageComponent from "../publicComponent/pageComponent";
    export default {
      name: "myClue",
      components: {PageComponent, DisplayBars, ScreeningComponents, Action_tit},
      data(){
        return{
          moveloding:false,
          pageData:[
            {
              pageNumber:1,
              row:20,
              countSum:0,
              radio:"queryCues",
              queryVo:{
                userId:this.userId()
              }
            },
            {
              pageNumber:1,
              row:20,
              countSum:0,
              radio:"querySubmersible",
              custQueryVo:{
                userId:this.userId()
              }
            }
          ],
          //是否移动或分配全部
          isSelect:"",
          ClueData:[],
          //员工ID
          nickId:"",
          //部门ID
          departId:"",
          departData:[],
          submersibleData:{
            userId:this.userId(),	//员工ID
            companyId:"",
            custType:"A",  //评级
            record:""    //意见
          },
          enterTheSubmersible:false,
          bars:{
            min:1,
            max:2,
          },
          isLookatThewHole:false,
          radio:"queryCues",
          //评级数据
          Grade:[
            {
              value: 'A',
              label: 'A:成单'
            }, {
              value: 'B',
              label: 'B:有兴趣'
            }, {
              value: 'C',
              label: 'C:暂无需求'
            }, {
              value: 'D',
              label: 'D:不感兴趣/挂电话'
            }, {
              value: 'E',
              label: 'E:接不通'
            }
          ],
          //下拉框数据
          data:{
            submersible:[
                {
                  value: 'address',
                  label: '地址'
                }, {
                  value: 'operation',
                  label: '行业'
                }, {
                  value: 'companyName',
                  label: '公司名'
                }
              ],
            clue:[
              {
                value: 'custType',
                label: '意向类型'
              },
              {
                value: 'companyName',
                label: '公司名'
              },
            ]
          },
        //潜客
        mySubmersibleData:{
          countSum:0
        },
        //线索
        myClueData:{},
        selectRep:{
          userId:this.userId(),	//员工ID
          ids:"",          //线索ID
          deptId:"",
          destId:""
        },
        list:[],
        //根据筛选条件分配线索
        allocateAll:{
          queryVo:{
            userId:this.userId(),
          }
        },
        //根据筛选条件分配潜客
        allocateAllClue:{
          custQueryVo:{
            userId:this.userId(),
          }
        }
        }
      },
      watch:{
        selectRep:{
          handler (cval, oval) {
            this.nubEmployee(false);
          },
          deep: true
        },
        //监听线索
        myClueData:{
          handler (cval, oval) {
            this.pageData[0].countSum = cval.countSum;
          },
          deep: true
        },
        //监听潜客
        mySubmersibleData:{
          handler (cval, oval) {
            this.pageData[1].countSum = cval.countSum;
          },
          deep: true
        }
      },
      computed:{
        myUserId:function(){
          return window.localStorage['id']
        },
      },
      methods:{
        handleMobileClueis:function(val){
          this.getDepartmentList();
          this.isSelect=val;
        },
        userId:function(){
          const value = this.$route.query.value;
          if(value){
            var userId = value;
          }else {
            var userId = window.localStorage['id'];
          }
          return userId
        },
        joinRemarks:function(){
          var url = this.host + 'custIntention/saveCustIntention';
          var data = this.submersibleData;
          this.msgDialog(url,data);
          this.enterTheSubmersible=false;
        },
        nubEmployee:function () {
          var that = this;
          that.axios({
            url:this.host+'user/searchDeptEmployee',
            method: 'post',
            data:{
              id:this.selectRep.deptId
            }
          }).then(function (res){
            that.ClueData = res.data.data;
          })
        },
        getDepartmentList:function () {
          var that = this;
          this.axios({
            method: 'POST',
            data:{
              id:window.localStorage['cId']
            },
            url: this.host + "dept/searchDeptDeatil",
          }).then(function (res) {
            that.departData = res.data.data;
            that.isLookatThewHole = true;
          });
        },
        handleSelectionChange:function(list){
          this.selectRep.ids = this.getUpdataId(list,"ids",this.selectRep.ids);
        },
        goDetails:function(v){
          this.$router.push({ name: 'company',params:{value:v}});
        },
        handleSelect:function(v){
          this.radio = v;
          this.isRadioGetData()
        },
        //删除
        sumDelete:function(id){
          this.$confirm('删除该记录将进入回收站, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            var data = {
              companyId:id,
              userId:window.localStorage['id']
            };
            var url = this.host + 'custIntention/deleteCustomersByCompanyIds';
            this.msgDialog(url,data);
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
          });
        },
        ThewHole:function(){
          if(this.radio=="queryCues"&&!this.isSelect){
            var data = this.selectRep;
            var url = this.host + 'move/moveDeptPoolToDeptPool';
          }else if(this.radio=="queryCues"&&this.isSelect){
            this.allocateAll.queryVo.startRow = this.bars.min;
            this.allocateAll.queryVo.endRow = (this.bars.max - this.bars.min)+1;
            this.allocateAll.destId = this.selectRep.destId;
            var data = this.allocateAll;
            var url = this.host + 'move/movePersonPoolByCondition';
          }
          this.moveloding = true;
          this.msgDialog(url,data);
        },
        msgDialog:function(url,data){
          var that = this;
          this.axios({
            method:'POST',
            data:data,
            url: url,
          }).then(function (res) {
            that.moveloding = false;
            that.isLookatThewHole = false;
            if(res.data.status==200){
              that.isRadioGetData(false);
              that.$message({
                message: res.data.msg,
                type: 'success'
              });
            }else {
              this.$message.error(res.data.msg);
            }
          });
        },
        pushData:function(data){
          if(this.radio=="queryCues"){
            this.allocateAll.queryVo = data;
            this.pageData[0].pageNumber = 1;
            this.pageData[0].queryVo = data;
            this.isRadioGetData()
          }else {
            this.allocateAllClue.custQueryVo = data;
            this.pageData[1].pageNumber = 1;
            this.pageData[1].custQueryVo = data;
            this.isRadioGetData()
          }
        },
        handleSizeChange:function () {
          this.isRadioGetData();
        },
        handleCurrentChange:function () {
          this.isRadioGetData();
        },
        //根据radio请求线索或潜客
        isRadioGetData:function (isMsg=true) {
          if(this.radio=="queryCues"){
            var url = this.host+"companyInfo/getPersonPoolByCondition";
            this.getData(url,this.pageData[0],"myClueData",isMsg)
          }else {
            var url = this.host+"custIntention/getCustomersByUserId";
            this.getData(url,this.pageData[1],"mySubmersibleData",isMsg)
          }
        }
      },
      created:function () {
        const radio = this.$route.query.radio;
        if(radio){
          this.radio = radio;
        }
        this.isRadioGetData();
      }
    }
</script>

<style scoped>

</style>
