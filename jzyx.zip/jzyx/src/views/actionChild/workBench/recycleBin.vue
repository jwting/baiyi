<template>
    <div class="action_child">
      <action_tit title="回收站"></action_tit>
      <div class="text-margin">
        <el-button type="primary" @click="reduction">批量还原</el-button>
      </div>
      <el-table
        :data="recycleBinData.data"
        style="width: 100%;margin: 0 auto;"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column label="公司名" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.companyName}}</span>
          </template>
        </el-table-column>
        <el-table-column label="意向类型" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.custType}}</span>
          </template>
        </el-table-column>
        <el-table-column label="跟进记录" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.record}}</span>
          </template>
        </el-table-column>
        <el-table-column label="上次跟进时间" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.lastDate}}</span>
          </template>
        </el-table-column>
        <el-table-column label="触达时间" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.firstDate}}</span>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="recycleBinData.countSum>10"
        style="text-align: right;margin-top: 20px"
        :background="true"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="allocateAllClue.row"
        :current-page.sync="allocateAllClue.pageNumber"
        :pager-count="7"
        layout="total, sizes, prev, pager, next, jumper"
        :total="recycleBinData.countSum">
      </el-pagination>
    </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
      name: "recycleBin",
      components: {Action_tit},
      data(){
        return{
          selectRep:{
            userId:window.localStorage['id'],
            ids:"",
          },
          allocateAllClue:{
            pageNumber:1,
            row:20,
            countSum:0,
            radio:"查询潜客",
            custQueryVo:{
              userId:window.localStorage['id'],
            }
          },
          recycleBinData:{},
        }
      },
      methods:{
        reduction:function(){
          var data = this.selectRep;
          this.msgDialog(this.host+"custIntention/restoreCustIntention",data)
        },
        getUpdataCompanyId:function(data,type){
          if(type=="ids"){
            var ids = "";
            var that = this;
            for (var v of data){
              if(ids==""){
                ids = v.companyId;
              }else {
                ids = ids+','+v.companyId;
              }
            }
            return ids;
          }else if(type=="lists"){
            var arr = [];
            for (var v of data){
              if(v.is){
                arr.push(v);
              }
            }
            return arr;
          }
        },
        handleSelectionChange:function (list) {
          this.selectRep.ids = this.getUpdataCompanyId(list,"ids");
        },
        handleSizeChange:function () {
          this.isRadioGetData();
        },
        handleCurrentChange:function () {
          this.isRadioGetData();
        },
        msgDialog:function(url,data){
          var that = this;
          this.axios({
            method:'POST',
            data:data,
            url: url,
          }).then(function (res) {
            that.isLookatThewHole = false;
            if(res.data.status==200){
              that.isRadioGetData();
              that.$message({
                message: res.data.msg,
                type: 'success'
              });
            }else {
              this.$message.error(res.data.msg);
            }
          });
        },
        isRadioGetData:function () {
          var url = this.host+"custIntention/getRecycleBinCustomers";
          this.getData(url,this.allocateAllClue,"recycleBinData")
        }
      },
      created:function () {
        this.isRadioGetData();
      }
    }
</script>

<style scoped>

</style>
