<template>
    <div class="action_child">
      <action_tit title="智能匹配"></action_tit>
      <el-row class="tit">
        <el-col :span="16"><div class="w">上传种子企业</div></el-col>
      </el-row>
      <el-row class="upload">
        <el-col :span="16">
          <el-row class="border">
            <el-col :span="12">
              <a href="http://jzyx.bybigdata.com/excel/example/example.xlsx" class="dowlode">
                <img class="img" src="https://shop.bybigdata.com/image/updata.png">
                <div class="el-upload__text center" style="color: #616161;text-decoration: none">点击按钮下载样本</div>
              </a>
              <div class="center"><a class="a" href="http://jzyx.bybigdata.com/excel/example/example.xlsx">下载样本</a></div>
            </el-col>
            <el-col :span="12">
              <el-upload
                class="upload-demo"
                ref="upload"
                :limit="1"
                drag
                :action="hostChild+'clue/upload'"
                :auto-upload="false"
                :headers="token"
                :on-success="onSuccess"
                multiple>
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                <div class="el-upload__text">只能上传xlsx文件</div>
              </el-upload>
              <div class="center"><el-button @click="touplode" type="primary">上传样本</el-button></div>
            </el-col>
          </el-row>
        </el-col>
        <el-collapse-transition>
          <el-col v-if="isUpdata" :span="8">
            <div  class="center mar">
              <span>当前种子数量 </span>
              <span class="red">{{resData.seedNumber}}</span>
              <span>，有效数量 </span>
              <span class="red">{{resData.effectiveNumber}}</span>
              <span>，种子质量 </span>
              <span class="red">{{resData.quality===0?"差":resData.quality===1?"良":resData.quality===2?"优":""}}</span>
            </div>
            <div  class="center"><el-button class="btn" :disabled="!isSucc" :type="isSucc?'primary':isSu?'success':'info'" @click="uplode" :loading="loading">{{btnText}}</el-button></div>
            <div v-if="loading" class="center" style="margin-top: 20px;color: #585858">{{loadText}}<span v-show="loading" style="color: #E6A23C">&nbsp;&nbsp;&nbsp;请勿刷新当前页面哦！</span></div>
          </el-col>
        </el-collapse-transition>
      </el-row>
    </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
        name: "Intelligent",
      components: {Action_tit},
      data(){
          return{
            name:"",
            hostChild:"",
            isSu:false,
            isSucc:false,
            loading:false,
            btnText:"开始匹配",
            loadText:"",
            setInt:"",
            init:"",
            isUpdata:false,
            resData:{
              effectiveNumber:"",
              filePath:"",
              seedNumber:"",
              quality:""
            }
          }
        },
        computed:{
          token:function () {
            var obj = {};
            obj[this.codeKey] = window.localStorage[this.codeKey];
            return obj;
          }
        },
        methods:{
          onSuccess:function(res){
            var that = this;
            if(res.status==200){
              that.isUpdata = true;
              that.isSu = false;
              that.resData = {
                effectiveNumber:"",
                filePath:"",
                seedNumber:"",
                quality:""
              };
              that.$message({
                type: 'success',
                message: '上传成功，正在检测'
              });
              that.btnText = "正在检测中，请稍后";
              that.loading = true;
              that.loadText = "正在检测中";
              that.axios({
                method: 'post',
                url: that.host+'clue/match',
                data:  {
                  filePath:res.data,
                  userId:window.localStorage["id"]
                },
              }).then(function (res){
                if(res.data.status==200){
                  if(res.data.data.quality!=0){
                    that.isSucc = true;
                    that.btnText = "开始匹配";
                    that.loading = false;
                  }else {
                    that.isSucc = false;
                    that.btnText = "种子质量差";
                    that.loading = false;
                  }
                  that.resData.effectiveNumber = res.data.data.effectiveNumber;
                  that.resData.quality = res.data.data.quality;
                  that.resData.seedNumber = res.data.data.seedNumber;
                  that.resData.filePath = res.data.data.filePath;
                  that.$message({
                    type: 'success',
                    message: '检测成功'
                  });
                }
              })
            }else {
              that.isSucc = false;
              that.$message.error('上传失败，请上传正确的样本');
            }
          },
          touplode:function(){
            this.$refs.upload.submit();
          },
          uplode:function () {
            var that = this;
            this.loading = true;
            this.btnText = "上传中，请稍后";
            that.loadText = "上传中";
            that.axios({
              method: 'post',
              url: that.host+'clue/startMatch',
              data: {
                fileName:that.resData.filePath,
                userId:window.localStorage["id"]
              },
            }).then(function (res){
               that.$router.push({ name: 'Matching',params:{value:'0'}});
            });
          }
        },
        created:function () {
          this.hostChild = this.host;
        }
    }
</script>

<style scoped>
  .a{
    display: inline-block;
    text-decoration: none;
    height: 34px;
    line-height: 34px;
    color: #fff;
    border-radius: 3px;
    width: 88px;
    background: #409EFF;
    font-size: 14px;
  }
  .w{
    font-weight: 600;
    line-height: 45px;
  }
  .upload-demo{
    text-align: center;
    margin-bottom: 10px;
    background: none;
  }
  .dowlode{
    display: block;
    overflow: hidden;
    width: 360px;
    height: 180px;
    margin: 0 auto;
    margin-bottom: 15px;
    border-radius: 5px;
    border: dashed 1px #d4d4d4;
    background: #fff;
    cursor: pointer;
  }
  .img{
    display: block;
    margin: 0 auto;
    width: 65px;
    height: 65px;
    margin-top: 30px;
    margin-bottom: 10px;
  }
  .upload{
    height: 230px;
  }
  .border{
    border-right: dashed 1px #d4d4d4;
  }
  .btn {
    height: 40px;
    width: 60%;
  }
  .mar{
    margin-top: 75px;
    margin-bottom: 15px;
    overflow: hidden;
    height: 36px;
    line-height: 36px;
  }
  .mar>span{
    width: auto;
  }
</style>
