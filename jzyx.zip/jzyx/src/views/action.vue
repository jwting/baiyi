<template>
    <div class="action_app">
        <el-aside>
          <div class="action_nav">
            <div class="company-name" @click="getHome"><span>{{companyName}}</span></div>
            <navigation-bar
              :nav-data="nav"
              :current-selection="selectionName"
              :props="props"
              :auto-open="true"
              @onChangeClick="handleChildChange">
           </navigation-bar> 
          </div>
        </el-aside>
        <el-main class="main">
          <keep-alive>
             <router-view v-if="$route.meta.keepAlive"></router-view>
          </keep-alive>
          <router-view v-if="!$route.meta.keepAlive"></router-view>
        </el-main>
    </div>
</template>

<script>
    export default {
      name: "action",
      data(){
          return{
            props:{
              lable:'text',
              children:'child',
              selection:'name'
            },
            selectionName:"",
            companyName:"",
            nav:[
              {
                text:"数据统计",
                icon:"fa fa-area-chart",
                jt:"https://shop.bybigdata.com/image/右箭头.png",
                child:[
                  {
                    text:"昨日概况",
                    name:"yesterdayStatistics",
                    value:"0"
                  },
                  {
                    text:"跟进效果",
                    name:"followUpStatistics",
                    value:"0"
                  },
                  {
                    text:"当前统计",
                    name:"currentStatistics",
                    value:"0"
                  }
                ]
              },
              {
              text:"线索筛选",
              icon:"fa fa-address-card-o",
              jt:"https://shop.bybigdata.com/image/右箭头.png",
              child:[
                      {
                        text:"规则筛选",
                        name:"screening",
                        value:"0"
                      },
                      {
                        text:"筛选历史",
                        name:"Historical",
                        value:"0"
                      },
                  ]
              },
              {
                text:"智能筛选",
                icon:"fa fa-eye",
                jt:"https://shop.bybigdata.com/image/右箭头.png",
                child:[
                  {
                    text:"智能匹配",
                    name:"Intelligent",
                    value:"0"
                  },
                  {
                    text:"匹配结果",
                    name:"Matching",
                    value:"0"
                  },
                ]
              }, {
                text:"工作台",
                icon:"fa fa-bars",
                jt:"https://shop.bybigdata.com/image/右箭头.png",
                child:[
                  {
                    text:"我的线索",
                    name:"myClue",
                    value:"0"
                  },
                  {
                    text:"部门线索",
                    name:"departmentalClues",
                    value:"0"
                  },
                  {
                    text:"公司线索",
                    name:"companyClue",
                    value:"0"
                  },
                  {
                    text:"回收站",
                    name:"recycleBin",
                    value:"0"
                  },
                ]
              }],
          }
        },
        methods:{
          getHome:function(){
            this.$router.push({ name:"home",params:{value:0}});
            this.selectionName = "home"
          },
          handleChildChange(val){
            this.selectionName = val.name
            this.$router.push({ name:val.name,params:{value:val.value}});
          },
        },
        created:function () {
          this.selectionName = this.$route.name;
          this.axios({
            method: 'get',
            url: this.host+'user/tokenGetUser?userId='+window.localStorage['id'],
          }).then( res=>{
            if(res.data.status==200){
              this.companyName = res.data.data.companyName;
              this.$store.commit('setUser',{
                deptName: res.data.data.deptName,
                userName:res.data.data.nickName,
                integral:res.data.data.integral
              });
            }
          });
        }
    }
</script>

<style scoped>
  .main{
    margin-left: 190px;
    margin-right: 10px;
    padding: 0;
  }
  .company-name{
    height: 60px;
    background: #363e4f;
    line-height: 60px;
    color: #fff;
    background-image: url("https://svc.bybigdata.com/image/byicon-1.png");
    background-size: 24px auto;
    background-repeat: no-repeat;
    background-position: 18px center;
    padding:0 15px 0 50px;
    margin-bottom: 10px;
    cursor: pointer;
    text-align: left;
    overflow: hidden;
  }
  .company-name>span{
    font-size: 15px;
    font-weight: 600;
  }
  .action_nav{
    position: fixed;
    left: 0;
    top: 0;
    width: 180px;
    height: 1000px;
    background: #464c5b;
  }
</style>
