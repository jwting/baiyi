<template>
  <div class="login">
    <div class="login-header">
      <span class="login-header-text">百邑大数据精准营销系统</span>
    </div>
    <div class="login-footer">
      <span class="by_iphone">客服电话：18023600582</span>
    </div>
    <div class="login-box">
      <div class="loginInput">
        <div class="tit-icon">
          <i class=" fa fa-user-circle-o"></i>
        </div>
        <div class="myinput">
          <el-input v-model="loginData.userName" class="user_input" placeholder="请输入用户名">
            <el-button slot="prepend" class="input-icon" icon="fa fa-user-circle-o"  disabled="disabled"></el-button>
          </el-input>
          <div class="input_ti"><span v-show="isUser=='用户名'">{{userText}}</span></div>
        </div>
        <div class="myinput">
          <el-input v-model="loginData.password" type="password" class="user_input" placeholder="请输入密码">
            <el-button slot="prepend" class="input-icon" icon="fa fa-unlock-alt" disabled="disabled"></el-button>
          </el-input>
          <div class="input_ti"><span v-show="isUser=='密码'">{{userText}}</span></div>
        </div>
        <div class="myinput">
          <el-input v-model="loginData.answer" class="code_input" placeholder="图片验证码">
            <el-button slot="prepend" class="input-icon" icon="fa fa-user-circle-o" disabled="disabled"></el-button>
          </el-input>
          <img class="code_img" :src="codeimg" @click="getCodeImg">
          <div class="input_ti"><span v-show="isUser=='验证码'">{{userText}}</span></div>
        </div>
        <div class="myinput">
          <el-button :loading="isLogin" :disabled="isLogin" class="user_buttom" @click="loginSubmit" type="primary">登录</el-button>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
    export default {
        name: "login",
        data(){
          return{
            isLogin:false,
            userText:"",
            isUser:"",
            loginData:{
              userName:"",
              password:"",
              answer:"",
              answerId:""
            },
            codeimg:""
          }
        },
        methods:{
          //点开切换验证码
          getCodeImg:function(){
            this.getCode();
          },
          //获取验证码
          getCode:function(){
            var that = this;
            that.axios({
              url:this.host+'user/verificationCode',
              method: 'get',
            }).then(function (res){
              if(res.data.status == 200){
                that.codeimg = res.data.data.image;
                that.loginData.answerId = res.data.data.answerId;
              }
            })
          },
          //登录提交
          loginSubmit:function () {
            //表单验证
            if(this.loginData.vecodeValue==""){
              this.isUser="验证码";
              this.userText="请输入图片验证码";
              return;
            }else if(this.loginData.userName==""){
              this.isUser="用户名";
              this.userText="请输入用户名";
              return;
            }else if(this.loginData.userPaw==""){
              this.isUser="密码";
              this.userText="请输入密码";
              return;
            }
            this.isLogin = true;
            //登录请求
            this.axios({
              method: 'post',
              url: this.host+'user/login',
              data:this.loginData,
            }).then( res=>{
                this.isLogin = false;
                window.localStorage['state'] = res.data.data.state;
                window.localStorage["id"] = res.data.data.user.id;
                window.localStorage["cId"] = res.data.data.user.cId;
                window.localStorage["dId"] = res.data.data.user.dId;
                window.localStorage[this.codeKey] = res.data.data[this.codeKey];
                this.axios.defaults.headers.common[this.codeKey] =  res.data.data[this.codeKey];
                this.$router.push({ name: 'home',params:{value:'0'}});
            }).catch((msg)=>{
                this.isLogin = false;
                this.getCode()
                this.isUser="验证码";
                this.userText=msg
            });
          },
          handle(){
            if(!this.isLogin){
              var key = window.event.keyCode;
              if(key == 13){
                this.loginSubmit();
              }
            }
          }
        },
        beforeDestroy:function(){
          document.removeEventListener('keydown',this.handle,false)
        },
        created:function () {
          this.getCode();
          document.addEventListener('keydown',this.handle,false)
        }
    }
</script>

<style>
  .login-footer{
    position: fixed;
    width: 100%;
    height: 50px;
    bottom: 10px;
  }
  .login-header-text{
    font-size: 18px;
    color: #fff;
    font-weight: 600;
  }
  .tit-icon{
    font-size: 45px;
    margin-bottom: 18px;
    color: #909399;
  }
  .input-icon{
    width: 45px;
    text-align: left;
  }
  .login-header{
    position: fixed;
    width: 100%;
    height: 55px;
    line-height: 55px;
    background: #222;
    text-align: left;
    padding-left: 80px;
    background-image: url("https://svc.bybigdata.com/image/byicon-1.png");
    background-size: 35px auto;
    background-repeat: no-repeat;
    background-position: 30px center;
  }
  .login{
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url("https://svc.bybigdata.com/image/login.png");
    background-position: center center;
  }
  .login-box{
    display: flex;
    display:-webkit-flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
  }
  .loginInput{
    width: 400px;
    padding-top:20px;
    padding-bottom:30px;
    background: #fff;
    border-radius: 7px;
    margin-bottom: 130px;
    align-self: center;
  }
  .user_input>input{
    height: 40px !important;
  }
  .code_input>input{
    height: 40px !important;
  }
  .myinput{
    width: 300px;
    margin: 0 auto;
    margin-bottom: 5px;
    overflow: hidden;
  }
  .code_input{
    float: left;
    height: 40px;
    width: 170px !important;
  }
  .code_img{
    height: 40px;
    float: right;
    cursor: pointer;
    width: 120px;
  }
  .user_buttom{
    width: 300px;
    height: 40px;
    margin-bottom: 5px;
    border-radius: 5px;
    font-weight: 600;
  }
  .input_ti{
    clear: both;
    height: 12px;
    line-height: 12px;
    text-align: right;
    padding-left: 6px;
    margin-top: 5px;
    color: red;
  }
  .input_ti>span{
    font-size: 12px;
  }
  .by_iphone{
    color: #909399;
  }
</style>
