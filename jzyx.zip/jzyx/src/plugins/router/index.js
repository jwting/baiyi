import Vue from 'vue'
import Router from 'vue-router'
import login from '@/views/login'
import action from '@/views/action'
const screening = resolve => require(['@/views/actionChild/ClueScreening/screening'], resolve)
const Historical = resolve => require(['@/views/actionChild/ClueScreening/Historical-records'], resolve)
const Intelligent = resolve => require(['@/views/actionChild/IntelligentScreening/Intelligent'], resolve)
const Matching = resolve => require(['@/views/actionChild/IntelligentScreening/Matching'], resolve)
const mdetails = resolve => require(['@/views/actionChild/IntelligentScreening/details'], resolve)
const user = resolve => require(['@/views/actionChild/PersonalSettings/user'], resolve)
const company = resolve => require(['@/views/actionChild/workBench/company'], resolve)
const management = resolve => require(['@/views/actionChild/PersonalSettings/management'], resolve)
const authority = resolve => require(['@/views/actionChild/PersonalSettings/authority'], resolve)
const companyClue = resolve => require(['@/views/actionChild/workBench/companyClue'], resolve)
const departmentalClues = resolve => require(['@/views/actionChild/workBench/departmentalClues'], resolve)
const myClue = resolve => require(['@/views/actionChild/workBench/myClue'], resolve)
const recycleBin = resolve => require(['@/views/actionChild/workBench/recycleBin'], resolve)
const currentStatistics = resolve => require(['@/views/actionChild/statisticsPage/current-statistics'], resolve)
const followUpStatistics = resolve => require(['@/views/actionChild/statisticsPage/follow-up-statistics'], resolve)
const yesterdayStatistics = resolve => require(['@/views/actionChild/statisticsPage/yesterday-statistics'], resolve)


import home from '@/views/actionChild/homePage/home'
import axios from 'axios'

Vue.use(Router)
const router = new Router({
  canReuse() {
    return true
  },
  mode:'history',
  routes: [
    {
      path: '/',
      name: 'login',
      component: login
    },
    {
      path: '/action/:value',
      name: 'action',
      props: { value: false },
      component: action,
      children: [
        {
          path: 'home',
          name: 'home',
          component:home,
        },
        //当前统计
        {
          path: 'currentStatistics',
          name: 'currentStatistics',
          component:currentStatistics,
        },
        //昨日统计
        {
          path: 'yesterdayStatistics',
          name: 'yesterdayStatistics',
          component:yesterdayStatistics,
        },
        //跟进效果
        {
          path: 'followUpStatistics',
          name: 'followUpStatistics',
          component:followUpStatistics,
        },
        //线索筛选
        {
          path: 'screening',
          name: 'screening',
          component:screening,
          meta: {
            keepAlive: true // 需要被缓存
          }
        },
         //首页
        {
          path: '/',
          component:home
        },
         //权限管理
        {
          path: 'authority',
          component:authority,
          name: 'authority',
        },
        //回收站
        {
          path: 'recycleBin',
          component:recycleBin,
          name: 'recycleBin',
        },
        //我的线索
        {
          path: 'myClue',
          component:myClue,
          name: 'myClue',
        },
        {
          path: 'departmentalClues',
          component:departmentalClues,
          name: 'departmentalClues',
        },
        {
          path: 'company',
          name: 'company',
          component:company,
        },
        {
          path: 'companyClue',
          name: 'companyClue',
          component:companyClue,
        },
        {
          path: 'Historical',
          component:Historical,
          name: 'Historical',
        },
        //智能匹配
        {
          path: 'Intelligent',
          component:Intelligent,
          name: 'Intelligent',
          meta: {
            keepAlive: true // 需要被缓存
          }
        },
        //员工部门
        {
          path: 'management',
          component:management,
          name: 'management',
        },
        {
          path: 'Matching',
          component:Matching,
          name: 'Matching',
        },
        {
          path: 'mdetails',
          component:mdetails,
          name: 'mdetails',
        },
        {
          path: 'user',
          component:user,
          name: 'user',
        }
      ]
    },
  ],
});
//配置路由跳转信息
router.beforeEach ((to, from, next) => {
  if(from.name=='Historical'&&to.name=='screening'&&to.params.value!=='0'){
    to.meta.keepAlive = false
  }else if(to.name=='screening'){
    to.meta.keepAlive = true
  }
  next();
});
export default router;
