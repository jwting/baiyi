import Vue from "vue";

//连接文件下载方法
Vue.prototype.urlDownload = function(url){
  let iframe = document.createElement('iframe')
  iframe.style.display = 'none'
  iframe.src = url
  iframe.onload = function () {
    document.body.removeChild(iframe)
  }
  document.body.appendChild(iframe)
}

//二进制文件流文件下载方法
Vue.prototype.download = function (data) {
  if (!data) {
    return
  }
  let url = window.URL.createObjectURL(new Blob([data]))
  let link = document.createElement('a')
  link.style.display = 'none'
  link.href = url
  link.setAttribute('download', 'excel.xlsx')
  document.body.appendChild(link)
  link.click()
},

//时间戳转日期方法
Vue.prototype.timestampToTime = function (timestamp) {
  if(!timestamp){
    return '/'
  }
  var date = new Date(timestamp); //获取一个时间对象
  var year = date.getFullYear();  // 获取完整的年份(4位,1970)
  var month = parseFloat(date.getMonth())+1;  // 获取月份(0-11,0代表1月,用的时候记得加上1)
  var date1 = date.getDate();  // 获取日(1-31)
  var hours = date.getHours();  // 获取小时数(0-23)
  var minutes = date.getMinutes();  // 获取分钟数(0-59)
  var seconds = date.getSeconds();  // 获取秒数(0-59)
  var time = year+"-"+month+"-"+date1+"  "+hours+":"+minutes+":"+seconds;
  //console.log(time)
  return time;
};

