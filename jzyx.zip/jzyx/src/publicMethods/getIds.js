import Vue from "vue";

Vue.prototype.getUpdataId = function(data,type,oldVal){
  if(!data){
    return type=="ids"?"":[];
  }
  if(type=="ids"){
    var ids = "";
    var that = this;
    for (var v of data){
      if(ids==""){
        ids = v.id;
      }else {
        ids = ids+','+v.id;
      }
    }
    return ids;
  }else if(type=="lists"){
      var arr = [];
      for (var v of data){
        if(v.is){
          arr.push(v);
        }
      }
      return arr;
  }
};
