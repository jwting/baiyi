// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import qs from 'qs'
import router from './plugins/router'
import Element from 'element-ui'
import store from './plugins/vuex'
import 'element-ui/lib/theme-chalk/index.css'
import region from '../static/region.js'
import navigationBar from './components/navigation-bar'
import timeQuery from './components/time-query'
import getData from './publicMethods/getData.js'
import './assets/style/font-awesome-4.7.0/css/font-awesome.css'
import './publicMethods/fileDownload.js'
import './publicMethods/getIds.js'
import './publicStyle/app.css'
import './plugins/axios'

Vue.use(navigationBar)
Vue.use(timeQuery)
Vue.use(region);0.

Vue.use(getData);
Vue.use(Element, { size: 'small' })
Vue.config.productionTip = false


Vue.prototype.qs = qs

Vue.prototype.host = "https://api.bybigdata.com/";
// Vue.prototype.host = "http://127.0.0.1:9001/"
// Vue.prototype.host = "http://192.168.20.240:9001/";
// Vue.prototype.host = "http://171.35.109.62:13801/";
// Vue.prototype.host = "/apis/";

new Vue({
  el: '#app',
  store,
  router,
  render:h =>h(App)
});
